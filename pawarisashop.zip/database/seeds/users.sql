INSERT INTO `users` (`id`, `name`, `email`, `role`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'pawarisa.shop2020@gmail.com', 'admin', NULL, '$2y$10$hKt8EL6HWewzo.ztokLg1.Sl2ndW59czsbpTGWZgmRFybqjBtqBLW', NULL, NOW(), NOW());
--
-- pass : 12345678
--
