<div class="form-group <?php echo e($errors->has('user_id') ? 'has-error' : ''); ?>">
    <label for="user_id" class="control-label"><?php echo e('User Id'); ?></label>
    <input class="form-control" name="user_id" type="number" id="user_id"
        value="<?php echo e(isset($profile->user_id) ? $profile->user_id : ''); ?>">
    <?php echo $errors->first('user_id', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
    <label for="phone" class="control-label"><?php echo e('Phone'); ?></label>
    <input class="form-control" name="phone" type="text" id="phone"
        value="<?php echo e(isset($profile->phone) ? $profile->phone : ''); ?>">
    <?php echo $errors->first('phone', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
    <label for="address" class="control-label"><?php echo e('Address'); ?></label>
    <textarea class="form-control" rows="5" name="address" type="textarea"
        id="address"><?php echo e(isset($profile->address) ? $profile->address : ''); ?></textarea>
    <?php echo $errors->first('address', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('score_total') ? 'has-error' : ''); ?>">
    <label for="score_total" class="control-label"><?php echo e('Score Total'); ?></label>
    <input class="form-control" name="score_total" type="number" id="score_total"
        value="<?php echo e(isset($profile->score_total) ? $profile->score_total : ''); ?>">
    <?php echo $errors->first('score_total', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('score_used') ? 'has-error' : ''); ?>">
    <label for="score_used" class="control-label"><?php echo e('Score Used'); ?></label>
    <input class="form-control" name="score_used" type="number" id="score_used"
        value="<?php echo e(isset($profile->score_used) ? $profile->score_used : ''); ?>">
    <?php echo $errors->first('score_used', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('score_usable') ? 'has-error' : ''); ?>">
    <label for="score_usable" class="control-label"><?php echo e('Score Usable'); ?></label>
    <input class="form-control" name="score_usable" type="number" id="score_usable"
        value="<?php echo e(isset($profile->score_usable) ? $profile->score_usable : ''); ?>">
    <?php echo $errors->first('score_usable', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/profile/form.blade.php ENDPATH**/ ?>