<div class="container">
    <div class="menu-area">
        <!-- Navbar -->
        <div class="navbar navbar-default" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="navbar-collapse collapse">
                <!-- Left nav -->
                <ul class="nav navbar-nav">
                    <?php if(auth()->guard()->check()): ?>
                    <li><a href="<?php echo e(url('/home')); ?>">หน้าแรก</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo e(url('/')); ?>">หน้าแรก</a></li>
                    <?php endif; ?>

                    <?php $__currentLoopData = App\Category::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="javascript:void(0)"><?php echo e($catname->name); ?><span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <?php $__currentLoopData = App\CategorySub::where('cat_id',$catname->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(url('products?&category_sub='.$item->id.'&sub_name='.$item->name)); ?>">
                                    <?php echo e($item->name); ?>

                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="contact.html">ติดต่อเรา</a></li>
                </ul>
            </div>
            <!--/.nav-collapse -->
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\ProjectsLaravel\khaopanshop\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>