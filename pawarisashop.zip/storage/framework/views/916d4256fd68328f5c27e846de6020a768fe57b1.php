<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Income <?php echo e($income->id); ?></div>
                <div class="card-body">

                    <a href="<?php echo e(url('/income')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i
                                class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                    <a href="<?php echo e(url('/income/' . $income->id . '/edit')); ?>" title="Edit Income"><button
                            class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                            Edit</button></a>

                    <form method="POST" action="<?php echo e(url('income' . '/' . $income->id)); ?>" accept-charset="UTF-8"
                        style="display:inline">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-danger btn-sm" title="Delete Income"
                            onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o"
                                aria-hidden="true"></i> Delete</button>
                    </form>
                    <br />
                    <br />

                    <div class="table-responsive">
                        <table class="table">
                            <tbody>
                                <tr>
                                    <th>ID</th>
                                    <td><?php echo e($income->id); ?></td>
                                </tr>
                                <tr>
                                    <th> Date </th>
                                    <td> <?php echo e($income->date); ?> </td>
                                </tr>
                                <tr>
                                    <th> Income </th>
                                    <td> <?php echo e($income->income); ?> </td>
                                </tr>
                                <tr>
                                    <th> Refer </th>
                                    <td> <?php echo e($income->refer); ?> </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/income/show.blade.php ENDPATH**/ ?>