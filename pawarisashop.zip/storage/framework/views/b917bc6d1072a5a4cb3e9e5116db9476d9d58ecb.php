<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    รายการสินค้าทั้งหมด <?php echo e($productCount); ?> รายาร
                    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(session('fail')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('fail')); ?>

                    </div>
                    <?php endif; ?>

                </div>
                <div class="card-body">
                    <a href="<?php echo e(url('/product/create')); ?>" class="btn btn-success btn-sm mr-2">
                        <i class="fa fa-plus" aria-hidden="true"></i>
                        เพิ่มสินค้าใหม่
                    </a>
                    <a href="<?php echo e(url('/product?search=สินค้าใกล้หมด')); ?>" class="btn btn-primary btn-sm mr-2">
                        สินค้าใกล้หมด
                    </a>
                    <a href="<?php echo e(url('/product?search=สินค้าลดราคา')); ?>" class="btn btn-warning btn-sm mr-2">
                        สินค้าลดราคา
                    </a>
                    <a href="<?php echo e(url('/product?search=สินค้ายกเลิกขาย')); ?>" class="btn btn-danger btn-sm mr-2">
                        สินค้ายกเลิกขาย
                    </a>
                    <a href="<?php echo e(url('/product')); ?>" class="btn btn-info btn-sm mr-2">
                        ทั้งหมด
                    </a>

                    <form method="GET" action="<?php echo e(url('/product')); ?>" accept-charset="UTF-8"
                        class="form-inline my-2 my-lg-0 float-right" role="search">
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search..."
                                value="<?php echo e(request('search')); ?>">
                            <span class="input-group-append">
                                <button class="btn btn-secondary" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                    </form>

                    <br />
                    <br />
                    <div class="table-responsive">
                        <table class="table table-striped table-sm" id="dataProd">
                            <thead>
                                <tr class="text-center">
                                    <th>No.</th>
                                    <th>รัสสินค้า</th>
                                    <th class="text-left">ประเภทย่อย</th>
                                    <th class="text-left">ชื่อสินค้า</th>
                                    <th>ราคา</th>
                                    <th>ต้นทุน</th>
                                    <th>ส่วนลด</th>
                                    <th>รูป-1</th>
                                    <th>รูป-2</th>
                                    <th>รูป-3</th>
                                    <th>จำนวน</th>
                                    <th>Rating</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td>
                                        <?php echo e(($product->currentpage()-1) * $product->perpage() + $loop->index + 1); ?>

                                    </td>
                                    <td><?php echo e($item->id); ?></td>
                                    <td class="text-left"><?php echo e($item->category_sub->name); ?></td>
                                    <td class="text-left"><?php echo e($item->name); ?></td>
                                    <td><?php echo e(number_format($item->price,2)); ?></td>
                                    <td><?php echo e(number_format($item->cost,2)); ?></td>
                                    <td><?php echo e(number_format($item->disc,2)); ?></td>
                                    <td>
                                        <?php if(Storage::exists('public/'.$item->photo1)): ?>
                                        <a href="javascript:void(0)" id="photoProd" data-img="<?php echo e($item->photo1); ?>"
                                            data-title="รูปสินค้า-1">
                                            <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->photo1); ?>" width="30px"
                                                height="35px" class="rounded-lg border border-success">
                                        </a>
                                        <?php else: ?>
                                        <i class="fas fa-exclamation-circle text-danger" style="font-size: 20px;"
                                            title="no photo"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(Storage::exists('public/'.$item->photo2)): ?>
                                        <a href="javascript:void(0)" id="photoProd" data-img="<?php echo e($item->photo2); ?>"
                                            data-title="รูปสินค้า-2">
                                            <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->photo2); ?>" width="30px"
                                                height="35px" class="rounded-lg border border-success">
                                        </a>
                                        <?php else: ?>
                                        <i class="fas fa-exclamation-circle text-danger" style="font-size: 20px;"
                                            title="no photo"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(Storage::exists('public/'.$item->photo3)): ?>
                                        <a href="javascript:void(0)" id="photoProd" data-img="<?php echo e($item->photo3); ?>"
                                            data-title="รูปสินค้า-3">
                                            <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->photo3); ?>" width="30px"
                                                height="35px" class="rounded-lg border border-success">
                                        </a>
                                        <?php else: ?>
                                        <i class="fas fa-exclamation-circle text-danger" style="font-size: 20px;"
                                            title="no photo"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($item->qty); ?></td>
                                    <td>
                                        <?php echo e($item->rating); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(url('/product/' . $item->id)); ?>" title="View Product">
                                            <button class="btn btn-info btn-sm">
                                                ดูสินค้า
                                            </button>
                                        </a>
                                        <a href="<?php echo e(url('/product/' . $item->id . '/edit')); ?>"
                                            title="Edit Product"><button class="btn btn-primary btn-sm">
                                                แก้ไข
                                            </button>
                                        </a>

                                        <form method="POST" action="<?php echo e(url('/product' . '/' . $item->id)); ?>"
                                            accept-charset="UTF-8" style="display:inline">
                                            <?php echo e(method_field('DELETE')); ?>

                                            <?php echo e(csrf_field()); ?>


                                            <?php if($item->status == 'ขาย'): ?>
                                            <input class="d-none" type="hidden" name="status" id="status" value="ยกเลิกขาย">
                                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Product"
                                                onclick="return confirm(&quot;คุณแน่ใช่ใช่ไหมที่จะยกขายสินค้ารายการนี้ ? ยืนยัน&quot;)">
                                                ยกเลิกขาย
                                            </button>
                                            <?php else: ?>
                                            <input class="d-none" type="hidden" name="status" id="status" value="ขาย">
                                            <button type="submit" class="btn btn-success btn-sm" title="Delete Product"
                                                onclick="return confirm(&quot;คุณแน่ใช่ใช่ไหมที่จะกลับมาขายสินค้ารายการนี้ ? ยืนยัน&quot;)">
                                                กลับมาขาย
                                            </button>
                                            <?php endif; ?>

                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="pagination-wrapper float-right">
                            <?php echo $product->appends(['search' => Request::get('search')])->render(); ?> </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal Photo Product-->
<div class="modal fade" id="ModalPhotoProd">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <!-- Message title-->
                </h5>
                <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center">
                <img id="PhotoProduct" class="img-fluid rounded-lg border border-success" width="350px" src="">
                <!-- Photo Product-->
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/product/index.blade.php ENDPATH**/ ?>