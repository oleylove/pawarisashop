
<div class="form-group <?php echo e($errors->has('cat_id') ? 'has-error' : ''); ?>">
    <label for="cat_id" class="control-label"><?php echo e('ประเภทหลัก'); ?></label>
    <textarea class="form-control" rows="5" name="cat_id" type="textarea"
        id="cat_id"><?php echo e(isset($product->cat_id) ? $product->cat_id : ''); ?></textarea>
    <?php echo $errors->first('cat_id', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('cat_id') ? 'has-error' : ''); ?>">
    <label for="cat_id" class="control-label"><?php echo e('ประเภทย่อย'); ?></label>
    <textarea class="form-control" rows="5" name="cat_id" type="textarea"
        id="cat_id"><?php echo e(isset($product->cat_id) ? $product->cat_id : ''); ?></textarea>
    <?php echo $errors->first('cat_id', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
    <label for="title" class="control-label"><?php echo e('Title'); ?></label>
    <input class="form-control" name="title" type="text" id="title"
        value="<?php echo e(isset($product->title) ? $product->title : ''); ?>">
    <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('content') ? 'has-error' : ''); ?>">
    <label for="content" class="control-label"><?php echo e('Content'); ?></label>
    <textarea class="form-control" rows="5" name="content" type="textarea"
        id="content"><?php echo e(isset($product->content) ? $product->content : ''); ?></textarea>
    <?php echo $errors->first('content', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
    <label for="price" class="control-label"><?php echo e('Price'); ?></label>
    <input class="form-control" name="price" type="number" id="price"
        value="<?php echo e(isset($product->price) ? $product->price : ''); ?>">
    <?php echo $errors->first('price', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('cost') ? 'has-error' : ''); ?>">
    <label for="cost" class="control-label"><?php echo e('Cost'); ?></label>
    <input class="form-control" name="cost" type="number" id="cost"
        value="<?php echo e(isset($product->cost) ? $product->cost : ''); ?>">
    <?php echo $errors->first('cost', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('disc') ? 'has-error' : ''); ?>">
    <label for="disc" class="control-label"><?php echo e('Disc'); ?></label>
    <input class="form-control" name="disc" type="number" id="disc"
        value="<?php echo e(isset($product->disc) ? $product->disc : ''); ?>">
    <?php echo $errors->first('disc', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('photo1') ? 'has-error' : ''); ?>">
    <label for="photo1" class="control-label"><?php echo e('Photo1'); ?></label>
    <input class="form-control" name="photo1" type="file" id="photo1"
        value="<?php echo e(isset($product->photo1) ? $product->photo1 : ''); ?>">
    <?php echo $errors->first('photo1', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('photo2') ? 'has-error' : ''); ?>">
    <label for="photo2" class="control-label"><?php echo e('Photo2'); ?></label>
    <input class="form-control" name="photo2" type="file" id="photo2"
        value="<?php echo e(isset($product->photo2) ? $product->photo2 : ''); ?>">
    <?php echo $errors->first('photo2', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('photo3') ? 'has-error' : ''); ?>">
    <label for="photo3" class="control-label"><?php echo e('Photo3'); ?></label>
    <input class="form-control" name="photo3" type="file" id="photo3"
        value="<?php echo e(isset($product->photo3) ? $product->photo3 : ''); ?>">
    <?php echo $errors->first('photo3', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('qty') ? 'has-error' : ''); ?>">
    <label for="qty" class="control-label"><?php echo e('Qty'); ?></label>
    <input class="form-control" name="qty" type="number" id="qty"
        value="<?php echo e(isset($product->qty) ? $product->qty : ''); ?>">
    <?php echo $errors->first('qty', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('hot') ? 'has-error' : ''); ?>">
    <label for="hot" class="control-label"><?php echo e('Hot'); ?></label>
    <input class="form-control" name="hot" type="number" id="hot"
        value="<?php echo e(isset($product->hot) ? $product->hot : ''); ?>">
    <?php echo $errors->first('hot', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('vote') ? 'has-error' : ''); ?>">
    <label for="vote" class="control-label"><?php echo e('Vote'); ?></label>
    <input class="form-control" name="vote" type="number" id="vote"
        value="<?php echo e(isset($product->vote) ? $product->vote : ''); ?>">
    <?php echo $errors->first('vote', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('score') ? 'has-error' : ''); ?>">
    <label for="score" class="control-label"><?php echo e('Score'); ?></label>
    <input class="form-control" name="score" type="number" id="score"
        value="<?php echo e(isset($product->score) ? $product->score : ''); ?>">
    <?php echo $errors->first('score', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('rating') ? 'has-error' : ''); ?>">
    <label for="rating" class="control-label"><?php echo e('Rating'); ?></label>
    <input class="form-control" name="rating" type="number" id="rating"
        value="<?php echo e(isset($product->rating) ? $product->rating : ''); ?>">
    <?php echo $errors->first('rating', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/product/form.blade.php ENDPATH**/ ?>