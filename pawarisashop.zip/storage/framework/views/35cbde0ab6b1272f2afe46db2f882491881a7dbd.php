<!-- start header top  -->
<div class="aa-header-top">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="aa-header-top-area">
                    <!-- start header top left -->
                    <div class="aa-header-top-left">
                        <!-- start cellphone -->
                        <div class="cellphone hidden-xs">
                            <p><span class="fab fa-facebook text-primary"></span>facebook</p>
                        </div>
                        <div class="cellphone hidden-xs">
                            <p><span class="fab fa-line text-success"></span>line@</p>
                        </div>
                        <div class="cellphone hidden-xs">
                            <p><span class="fas fa-phone-square-alt text-danger"></span>088-328-8235</p>
                        </div>

                        <!-- / cellphone -->
                    </div>
                    <!-- / header top left -->
                    <div class="aa-header-top-right">
                        <ul class="aa-head-top-nav-right">
                            <?php if(auth()->guard()->guest()): ?>
                                <li>
                                    <?php if(Route::has('register')): ?>
                                    <a href="javascript:void(0)" data-toggle="modal" data-target="#singin-modal">ลงทะเบียน</a>
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <a href="javascript:void(0)" data-toggle="modal" data-target="#login-modal">เข้าสู่ระบบ</a>
                                </li>
                            <?php else: ?>
                                <li><a href="<?php echo e(url('myaccount')); ?>">บัญชีของฉัน</a></li>
                                <li class="hidden-xs"><a href="<?php echo e(url('mywishlist')); ?>">สิ่งที่อยากได้</a></li>
                                <li><a href="<?php echo e(url('mycart')); ?>">รถเข็นของฉัน</a></li>
                                <li><a href="<?php echo e(url('mycheckout')); ?>">คำสั่งชื้อของฉัน</a></li>
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="javascript:void(0)" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                    </a>

                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                                document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                        </a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                            style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form><br>
                                        <?php if(Auth::user()->role == 'admin'): ?>
                                            <a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('mywishlist')); ?>">สิ่งที่อยากได้</a>
                                        <?php endif; ?>
                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- / header top  -->

<!-- start header bottom  -->
<div class="aa-header-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="aa-header-bottom-area">
                    <!-- logo  -->
                    <div class="aa-logo">
                        <!-- Text based logo -->
                        <a href="<?php echo e(url('/')); ?>">
                            <span class="fa fa-shopping-cart"></span>
                            <p>KhaoPan-<strong>Shop</strong> <span>ลงทะเบียนกับเราเพื่อรับแต้มสะสมแลกซื้อ</span></p>
                        </a>
                        <!-- img based logo -->
                        <!-- <a href="index.html"><img src="<?php echo e(url('/')); ?>/storage/img/logo.jpg" alt="logo img"></a> -->
                    </div>
                    <!-- / logo  -->
                    <!-- cart box -->
                    <?php if(auth()->guard()->check()): ?>
                    <div class="aa-cartbox">
                        <a class="aa-cart-link" href="<?php echo e(url('mycart')); ?>">
                            <span class="fa fa-shopping-basket"></span>
                            <span class="aa-cart-title">SHOPPING CART</span>
                            <span class="aa-cart-notify">
                                <?php echo e(App\OrderProduct::whereNull('po_id')->where('user_id', Auth::id())->count()); ?>

                            </span>
                        </a>
                        <div class="aa-cartbox-summary">
                            <ul>
                                <?php $__currentLoopData = App\OrderProduct::whereNull('po_id')->where('user_id',Auth::id())->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a class="aa-cartbox-img" href="javascript:void(0)">
                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->product->photo1); ?>">
                                    </a>
                                    <div class="aa-cartbox-info">
                                        <h4><a href="javascript:void(0)"><?php echo e($item->product->title); ?></a></h4>
                                        <p><?php echo e($item->qty . ' ชิ้น ' . number_format($item->net,2) . ' บาท'); ?></p>
                                    </div>
                                    <a class="aa-remove-product" href="javascript:void(0)"><span class="fa fa-times"></span></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <span class="aa-cartbox-total-title">
                                        รวมทั้งหมด
                                    </span>
                                    <span class="aa-cartbox-total-price">
                                        <?php echo e(number_format(App\OrderProduct::whereNull('po_id')->where('user_id', Auth::id())->sum('net'),2) . ' บาท'); ?>

                                    </span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>
                    <!-- / cart box -->
                    <!-- search box -->
                    <div class="aa-search-box">
                        <form action="">
                            <input type="text" name="search" id="search" placeholder="ค้นหาสินค้าที่คุณต้องการค่ะ ">
                            <button type="submit"><span class="fa fa-search"></span></button>
                        </form>
                    </div>
                    <!-- / search box -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- / header bottom  -->
<?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/layouts/header.blade.php ENDPATH**/ ?>