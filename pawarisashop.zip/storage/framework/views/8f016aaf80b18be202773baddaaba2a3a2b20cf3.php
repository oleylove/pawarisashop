<div class="row">
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
            <label for="title" class="control-label"><?php echo e('Title'); ?></label>
            <span class="text-danger"> *</span>
            <input class="form-control" name="title" type="text" id="title"
                value="<?php echo e(isset($config->title) ? $config->title : ''); ?>">
            <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('website') ? 'has-error' : ''); ?>">
            <label for="website" class="control-label"><?php echo e('Website'); ?></label>
            <input class="form-control" name="website" type="text" id="website"
                value="<?php echo e(isset($config->website) ? $config->website : ''); ?>">
            <?php echo $errors->first('website', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('facebook') ? 'has-error' : ''); ?>">
            <label for="facebook" class="control-label"><?php echo e('Facebook'); ?></label>
            <input class="form-control" name="facebook" type="text" id="facebook"
                value="<?php echo e(isset($config->facebook) ? $config->facebook : ''); ?>">
            <?php echo $errors->first('facebook', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('line') ? 'has-error' : ''); ?>">
            <label for="line" class="control-label"><?php echo e('Line'); ?></label>
            <input class="form-control" name="line" type="text" id="line"
                value="<?php echo e(isset($config->line) ? $config->line : ''); ?>">
            <?php echo $errors->first('line', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
            <label for="address" class="control-label"><?php echo e('ที่อยู่ร้าน'); ?></label>
                <textarea class="form-control" rows="3" name="address" type="textarea"
                id="address" required><?php echo e(isset($config->address) ? $config->address : ''); ?></textarea>
            <?php echo $errors->first('address', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('logo') ? 'has-error' : ''); ?>">
            <label for="logo" class="control-label"><?php echo e('Logo web'); ?></label>
            <input class="form-control" name="logo" type="file" id="logo"
                value="<?php echo e(isset($config->logo) ? $config->logo : ''); ?>">
            <?php echo $errors->first('logo', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('bbl_logo') ? 'has-error' : ''); ?>">
            <label for="bbl_logo" class="control-label"><?php echo e('Logo ธนาคารกรุงเทพ'); ?></label>
            <input class="form-control" name="bbl_logo" type="file" id="bbl_logo"
                value="<?php echo e(isset($config->bbl_logo) ? $config->bbl_logo : ''); ?>">
            <?php echo $errors->first('bbl_logo', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('kbsnk_logo') ? 'has-error' : ''); ?>">
            <label for="kbsnk_logo" class="control-label"><?php echo e('Logo ธนาคารกสิกรไทย'); ?></label>
            <input class="form-control" name="kbsnk_logo" type="file" id="kbsnk_logo"
                value="<?php echo e(isset($config->kbsnk_logo) ? $config->kbsnk_logo : ''); ?>">
            <?php echo $errors->first('kbsnk_logo', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('scb_logo') ? 'has-error' : ''); ?>">
            <label for="scb_logo" class="control-label"><?php echo e('Logo ธนาคารไทยพาณิชย์'); ?></label>
            <input class="form-control" name="scb_logo" type="file" id="scb_logo"
                value="<?php echo e(isset($config->scb_logo) ? $config->scb_logo : ''); ?>">
            <?php echo $errors->first('scb_logo', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('bay_logo') ? 'has-error' : ''); ?>">
            <label for="bay_logo" class="control-label"><?php echo e('Logo ธนาคารกรุงศรี'); ?></label>
            <input class="form-control" name="bay_logo" type="file" id="bay_logo"
                value="<?php echo e(isset($config->bay_logo) ? $config->bay_logo : ''); ?>">
            <?php echo $errors->first('bay_logo', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('bbl') ? 'has-error' : ''); ?>">
            <label for="bbl" class="control-label"><?php echo e('บัญชีธนาคารกรุงเทพ'); ?></label>
            <input class="form-control" name="bbl" type="text" id="bbl"
                value="<?php echo e(isset($config->bbl) ? $config->bbl : ''); ?>">
            <?php echo $errors->first('bbl', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('kbsnk') ? 'has-error' : ''); ?>">
            <label for="kbsnk" class="control-label"><?php echo e('บัญชีกสิกรไทย'); ?></label>
            <input class="form-control" name="kbsnk" type="text" id="kbsnk"
                value="<?php echo e(isset($config->kbsnk) ? $config->kbsnk : ''); ?>">
            <?php echo $errors->first('kbsnk', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('scb') ? 'has-error' : ''); ?>">
            <label for="scb" class="control-label"><?php echo e('บัญชีไทยพาณิชย์'); ?></label>
            <input class="form-control" name="scb" type="text" id="scb"
                value="<?php echo e(isset($config->scb) ? $config->scb : ''); ?>">
            <?php echo $errors->first('scb', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('bay') ? 'has-error' : ''); ?>">
            <label for="bay" class="control-label"><?php echo e('บัญชีกรุงศรี'); ?></label>
            <input class="form-control" name="bay" type="text" id="bay"
                value="<?php echo e(isset($config->bay) ? $config->bay : ''); ?>">
            <?php echo $errors->first('bay', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('photo1') ? 'has-error' : ''); ?>">
            <label for="photo1" class="control-label"><?php echo e('Photo1'); ?></label>
            <input class="form-control" name="photo1" type="file" id="photo1"
                value="<?php echo e(isset($config->photo1) ? $config->photo1 : ''); ?>">
            <?php echo $errors->first('photo1', '<p class="help-block">:message</p>'); ?>

        </div>

    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('photo2') ? 'has-error' : ''); ?>">
            <label for="photo2" class="control-label"><?php echo e('Photo2'); ?></label>
            <input class="form-control" name="photo2" type="file" id="photo2"
                value="<?php echo e(isset($config->photo2) ? $config->photo2 : ''); ?>">
            <?php echo $errors->first('photo2', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('photo3') ? 'has-error' : ''); ?>">
            <label for="photo3" class="control-label"><?php echo e('Photo3'); ?></label>
            <input class="form-control" name="photo3" type="file" id="photo3"
                value="<?php echo e(isset($config->photo3) ? $config->photo3 : ''); ?>">
            <?php echo $errors->first('photo3', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('photo4') ? 'has-error' : ''); ?>">
            <label for="photo4" class="control-label"><?php echo e('Photo4'); ?></label>
            <input class="form-control" name="photo4" type="file" id="photo4"
                value="<?php echo e(isset($config->photo4) ? $config->photo4 : ''); ?>">
            <?php echo $errors->first('photo4', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('photo5') ? 'has-error' : ''); ?>">
            <label for="photo5" class="control-label"><?php echo e('Photo5'); ?></label>
            <input class="form-control" name="photo5" type="file" id="photo5"
                value="<?php echo e(isset($config->photo5) ? $config->photo5 : ''); ?>">
            <?php echo $errors->first('photo5', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md">
        <div class="form-group <?php echo e($errors->has('photo6') ? 'has-error' : ''); ?>">
            <label for="photo6" class="control-label"><?php echo e('Photo6'); ?></label>
            <input class="form-control" name="photo6" type="file" id="photo6"
                value="<?php echo e(isset($config->photo6) ? $config->photo6 : ''); ?>">
            <?php echo $errors->first('photo6', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>

<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/config/form.blade.php ENDPATH**/ ?>