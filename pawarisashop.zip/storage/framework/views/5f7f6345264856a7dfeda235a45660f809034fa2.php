<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-9">
            <div class="card">
                <div class="card-header"><?php echo e(($keyword == 'category' ? 'เพิ่มประเภทหลัก' : 'เพิ่มประเภทย่อย')); ?></div>
                <div class="card-body">
                    <a href="<?php echo e(url('/category')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i
                                class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                    <br />
                    <br />

                    <?php if(session('alert')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('alert')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(session('alertFail')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('alertFail')); ?>

                    </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(url('/category')); ?>" accept-charset="UTF-8"
                        class="form-horizontal was-validated" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                        <?php if($keyword == 'category'): ?>
                        <div class="form-group">
                            <label for="name" class="control-label"><?php echo e('ประเภทหลัก'); ?></label>
                            <input class="form-control" name="name" type="text" id="name"
                                value="<?php echo e(isset($category->name) ? $category->name : ''); ?>" required>
                        </div>

                        <?php elseif($keyword == 'category_sub'): ?>
                        <div class="form-group">
                            <label for="name" class="control-label"><?php echo e('ประเภทหลัก'); ?></label>
                            <select class="form-control" name="cat_id" id="cat_id" required>
                                <option value="">เลือกประเภทหลัก</option>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="name" class="control-label"><?php echo e('ประเภทย่อย'); ?></label>
                            <input class="form-control" name="name" type="text" id="name"
                                value="<?php echo e(isset($category_sub->name) ? $category_sub->name : ''); ?>" required>
                        </div>
                        <?php endif; ?>
                        <input class="d-none" type="hidden" name="keyword" id="keyword" value="<?php echo e($keyword); ?>">

                        <div class="form-group">
                            <input class="btn btn-primary" type="submit" value="<?php echo e('Create'); ?>">
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/category/create.blade.php ENDPATH**/ ?>