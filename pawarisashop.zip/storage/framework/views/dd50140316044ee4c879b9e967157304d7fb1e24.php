<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Order <?php echo e($order->id); ?></div>
                <div class="card-body">

                    <a href="<?php echo e(url('/order')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i
                                class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                    <a href="<?php echo e(url('/order/' . $order->id . '/edit')); ?>" title="Edit Order"><button
                            class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                            Edit</button></a>

                    <form method="POST" action="<?php echo e(url('order' . '/' . $order->id)); ?>" accept-charset="UTF-8"
                        style="display:inline">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-danger btn-sm" title="Delete Order"
                            onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o"
                                aria-hidden="true"></i> Delete</button>
                    </form>
                    <br />
                    <br />

                    <div class="table-responsive">
                        <table class="table">
                            <tbody>
                                <tr>
                                    <th>ID</th>
                                    <td><?php echo e($order->id); ?></td>
                                </tr>
                                <tr>
                                    <th> User Id </th>
                                    <td> <?php echo e($order->user_id); ?> </td>
                                </tr>
                                <tr>
                                    <th> Remark </th>
                                    <td> <?php echo e($order->remark); ?> </td>
                                </tr>
                                <tr>
                                    <th> Shipping </th>
                                    <td> <?php echo e($order->shipping); ?> </td>
                                </tr>
                                <tr>
                                    <th> Disc </th>
                                    <td> <?php echo e($order->disc); ?> </td>
                                </tr>
                                <tr>
                                    <th> Total </th>
                                    <td> <?php echo e($order->total); ?> </td>
                                </tr>
                                <tr>
                                    <th> Tracking </th>
                                    <td> <?php echo e($order->tracking); ?> </td>
                                </tr>
                                <tr>
                                    <th> Score Total </th>
                                    <td> <?php echo e($order->score_total); ?> </td>
                                </tr>
                                <tr>
                                    <th> Status </th>
                                    <td> <?php echo e($order->status); ?> </td>
                                </tr>
                                <tr>
                                    <th> Checking At </th>
                                    <td> <?php echo e($order->checking_at); ?> </td>
                                </tr>
                                <tr>
                                    <th> Paid At </th>
                                    <td> <?php echo e($order->paid_at); ?> </td>
                                </tr>
                                <tr>
                                    <th> Cancelled At </th>
                                    <td> <?php echo e($order->cancelled_at); ?> </td>
                                </tr>
                                <tr>
                                    <th> Completed At </th>
                                    <td> <?php echo e($order->completed_at); ?> </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/order/show.blade.php ENDPATH**/ ?>