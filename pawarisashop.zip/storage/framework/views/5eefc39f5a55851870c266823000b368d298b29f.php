<?php $__env->startSection('title','Pawarisa Shop | Contact'); ?>

<?php $__env->startSection('content'); ?>
<!-- start contact section -->
<section id="aa-contact">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="aa-contact-area">
                    <div class="aa-contact-top">
                        <h2>เรายินดีที่จะช่วยเหลือคุณ</h2>
                        <p>หากมีบัญหาในการใช้งาน หรือการสั่งซื้อสินค้า หรืออื่นๆ กรุณาติดต่อเราได้ตลอดเวลาคะ</p>
                    </div>
                    <!-- contact map -->
                    <div class="aa-contact-map">
                        
                    </div>
                    <!-- Contact address -->
                    <div class="aa-contact-address">
                        <div class="row">
                            
                            <div class="col-md-12">
                                <div class="aa-contact-address-right">
                                    <address>
                                        <h4><?php echo e($config->title); ?></h4>
                                        
                                        <p><span class="fas fa-home"></span>  <?php echo e($config->address); ?></p>
                                        <p><span class="fas fa-phone-square-alt"></span> <?php echo e($config->phone); ?></p>
                                        <p><span class="fab fa-facebook"></span> <?php echo e($config->facebook); ?></p>
                                        <p><span class="fab fa-line"></span>  <?php echo e($config->line); ?></p>
                                    </address>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dailyshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\pawarisashop\resources\views/contact.blade.php ENDPATH**/ ?>