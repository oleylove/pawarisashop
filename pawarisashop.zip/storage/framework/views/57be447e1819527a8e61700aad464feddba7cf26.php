<?php $__env->startSection('title','Pawarisa Shop | Product Detail'); ?>

<?php $__env->startSection('content'); ?>
<!-- product category -->
<section id="aa-product-details">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="aa-product-details-area">
                    <div class="aa-product-details-content">
                        <div class="row">
                            <!-- Modal view slider -->
                            <div class="col-md-5 col-sm-5 col-xs-12">
                                <div class="aa-product-view-slider">
                                    <div id="demo-1" class="simpleLens-gallery-container">
                                        <div class="simpleLens-container">
                                            <div class="simpleLens-big-image-container">
                                                <a href="javascript:void(0)">
                                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo1); ?>"
                                                        class="simpleLens-big-image" width="350px" height="400px">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="simpleLens-thumbnails-container">
                                            <a data-big-image="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo1); ?>"
                                                class="simpleLens-thumbnail-wrapper" href="javascript:void(0)">
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo1); ?>" width="65xp"
                                                    height="75xp">
                                            </a>
                                            <a data-big-image="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo2); ?>"
                                                class="simpleLens-thumbnail-wrapper" href="javascript:void(0)">
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo2); ?>" width="65xp"
                                                    height="75xp">
                                            </a>
                                            <a data-big-image="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo3); ?>"
                                                class="simpleLens-thumbnail-wrapper" href="javascript:void(0)">
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo3); ?>" width="65xp"
                                                    height="75xp">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Modal view content -->
                            <div class="col-md-7 col-sm-7 col-xs-12">
                                <div class="aa-product-view-content">
                                    <h3><?php echo e($product->name); ?></h3>
                                    <div class="aa-price-block">
                                        <p class="aa-product-view-price">$34.99</p>
                                        <p class="aa-product-avilability">สินค้าทั้งหมด :
                                            <span><?php echo e($product->qty); ?></span></p>
                                        <p class="aa-product-avilability">ขายไปแล้ว : <span><?php echo e($product->sold); ?></span>
                                        </p>
                                    </div>
                                    <p><?php echo e($product->title); ?></p>
                                    <div class="col-md" style="display: inline-block; margin-right: 10px;">
                                        <h4>Size</h4>
                                        <div class="aa-prod-view-size">
                                            <a href="javascript:void(0)" class="product-size"> <?php echo e($product->size); ?></a>
                                        </div>
                                    </div>
                                    <div class="col-md" style="display: inline-block;">
                                        <h4>Color</h4>
                                        <div class="aa-prod-view-size">
                                            <a href="javascript:void(0)" class="product-color"><?php echo e($product->color); ?></a>
                                        </div>
                                    </div>
                                    
                                    <div class="aa-your-rating">
                                        <p>
                                            <?php echo e('คะแนนสินค้า : Vote:'.$product->vote .' | Score:'.$product->score .' | Rating:'.$product->rating .' | Like:'.$product->likes.''); ?>

                                        </p>

                                        <span class="ratingAverage2" data-average2="<?php echo e($product->rating); ?>"></span>
                                        <div class="barra2">
                                            <span class="bg2"></span>
                                            <span class="stars2">
                                                <?php for($i=1; $i<=5; $i++): ?> <span class="star2" data-vote="<?php echo e($i); ?>">
                                                    <span class="starAbsolute2"
                                                        style="background-image: url(<?php echo e(url('/')); ?>/storage/starvote/starpng.png);">
                                                    </span>
                                            </span>
                                            <?php endfor; ?>
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div class="aa-prod-view-bottom">
                                        <?php if($product->qty > 0): ?>
                                        <a class="aa-add-to-cart-btn add-to-mycart" data-prod_id="<?php echo e($product->id); ?>" data-user_id="<?php echo e(Auth::id() ? Auth::id() : ''); ?>"
                                            href="javascript:void(0)" title="หยิบใส่ตะกร้า">
                                            <span class="fa fa-shopping-cart" style="font-size: 20px;"></span>
                                            เพิ่มไปยังรถเข็น
                                        </a>
                                        <?php else: ?>
                                        <a class="aa-add-to-cart-btn" href="javascript:void(0)" title="สินค้าหมด" onclick="return alert(&quot;สินค้าหมดคะ!&quot;)">
                                            <span class="far fa-times-circle" style="font-size: 20px;"></span>
                                            Pre order
                                        </a>
                                        <?php endif; ?>

                                        <a class="aa-add-to-cart-btn add-to-wishlist" data-prod_id="<?php echo e($product->id); ?>" data-user_id="<?php echo e(Auth::id() ? Auth::id() : ''); ?>"
                                            href="javascript:void(0)" title="สนใจสินค้า">
                                            <span class="far fa-heart" style="font-size: 20px;"></span>
                                            สนใจสินค้า
                                        </a>
                                        <a class="aa-add-to-cart-btn add-to-likes" data-prod_id="<?php echo e($product->id); ?>" data-user_id="<?php echo e(Auth::id() ? Auth::id() : ''); ?>" href="javascript:void(0)" title="ถูกใจสินค้า">
                                            <span class="far fa-thumbs-up" style="font-size: 20px;"></span>
                                            ถูกใจสินค้า
                                        </a>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    

                    <div class="aa-product-details-bottom">
                        <ul class="nav nav-tabs" id="myTab2">
                            <li><a href="#description" data-toggle="tab">รายละเอียดสินค้า</a></li>
                            <li><a href="#review" data-toggle="tab">รีวิวสินค้า</a></li>
                        </ul>
                        
                        <div class="tab-content">
                            <div class="tab-pane fade in active" id="description">
                                <p> <?php echo e($product->content); ?></p>
                            </div>
                            <div class="tab-pane fade " id="review">
                                <div class="aa-product-review-area">
                                    <h4><?php echo e($review->count() .' รีวิว สำหรับ'. $product->name); ?> </h4>
                                    <ul class="aa-review-nav">
                                        <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <div class="media">
                                                <div class="media-left">
                                                    <a href="javascript:void(0)">
                                                        <img class="media-object"
                                                            src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->user->photo); ?>">
                                                    </a>
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading"><strong><?php echo e($item->user->name); ?></strong>
                                                        <span>
                                                            <?php echo e('เมื่อ ' .get_dateTime($item->created_at)); ?>

                                                        </span></h4>
                                                    <div class="aa-product-rating">
                                                        <?php if($vote_ck): ?>
                                                        <?php switch($vote_ck->score):
                                                        case (1): ?>
                                                        <span class="fa fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <?php break; ?>
                                                        <?php case (2): ?>
                                                        <span class="fa fa-star"></span>
                                                        <span class="fa fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <?php break; ?>
                                                        <?php case (3): ?>
                                                        <span class="fa fa-star"></span>
                                                        <span class="fa fa-star"></span>
                                                        <span class="fa fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <?php break; ?>
                                                        <?php case (4): ?>
                                                        <span class="fa fa-star"></span>
                                                        <span class="fa fa-star"></span>
                                                        <span class="fa fa-star"></span>
                                                        <span class="fa fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <?php break; ?>
                                                        <?php case (5): ?>
                                                        <span class="fa fa-star"></span>
                                                        <span class="fa fa-star"></span>
                                                        <span class="fa fa-star"></span>
                                                        <span class="fa fa-star"></span>
                                                        <span class="fa fa-star"></span>
                                                        <?php break; ?>
                                                        <?php endswitch; ?>
                                                        <?php else: ?>
                                                        <span class="far fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <span class="far fa-star"></span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <p><?php echo e($item->comment); ?></p>
                                                </div>
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <?php if(auth()->guard()->check()): ?>
                                    <h4>รีวิวสินค้า</h4>
                                    <h3>
                                        <a href="javascript:void(0)" class="vote">Vote :
                                            <span><?php echo e($product->vote); ?></span></a> |
                                        <a href="javascript:void(0)" class="totalScore">Score :
                                            <span><?php echo e($product->score); ?></span></a> |
                                        <a href="javascript:void(0)" class="rating">Rating :
                                            <span><?php echo e($product->rating); ?></span></a>
                                    </h3>
                                    <form method="POST" action="<?php echo e(route('comment')); ?>" accept-charset="UTF-8"
                                        class="aa-review-form form-horizontal was-validated"
                                        enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>


                                        <div class="aa-your-rating">
                                            <?php if($vote_ck): ?>
                                            <p>คะแนนคุณที่ให้กับสินค้านี้</p>
                                            <span class="ratingAverage" data-average="<?php echo e($vote_ck->score); ?>"></span>
                                            <span class="prod_id" data-id="<?php echo e($product->id); ?>"></span>
                                            <div class="barra">
                                                <span class="bg"></span>
                                                <span class="stars">
                                                    <?php for($i=1; $i<=5; $i++): ?> <span class="star" data-vote="<?php echo e($i); ?>"
                                                        id="voteProduct">
                                                        <span class="starAbsolute"
                                                            style="background-image: url(<?php echo e(url('/')); ?>/storage/starvote/starpng.png);">
                                                        </span>
                                                </span>
                                                <?php endfor; ?>
                                            </div>
                                            <?php else: ?>
                                            <p>ให้คะแนนสำหรับสินค้านี้</p>
                                            <span class="prod_id" data-id="<?php echo e($product->id); ?>"></span>
                                            <div class="barra">
                                                <span class="bg"></span>
                                                <span class="stars">
                                                    <?php for($i=1; $i<=5; $i++): ?> <span class="star" data-vote="<?php echo e($i); ?>"
                                                        id="voteProduct">
                                                        <span class="starAbsolute"
                                                            style="background-image: url(<?php echo e(url('/')); ?>/storage/starvote/starpng.png);">
                                                        </span>
                                                </span>
                                                <?php endfor; ?>
                                            </div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group">
                                            <input type="hidden" name="user_id" id="user_id" value="<?php echo e(Auth::id()); ?>"
                                                required>
                                            <input type="hidden" name="prod_id" id="prod_id"
                                                value="<?php echo e(request('search')); ?>" required>
                                            <label for="message">Your Comment</label>
                                            <textarea class="form-control" name="comment" id="comment">
                                            </textarea>
                                        </div>
                                        <button type="submit" class="btn btn-default aa-review-submit">Comment</button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Related product -->
                    <div class="aa-product-related-item">
                        <h3>สินค้าที่เกี่ยวข้อง</h3>
                        <ul class="aa-product-catg aa-related-item-slider">
                            <!-- start single product item -->
                            <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <figure>
                                    <a class="aa-product-img" href="<?php echo e(url('product-detail?search='.$item->id)); ?>"
                                        target="_blank">
                                        <?php if(Storage::exists('public/'.$item->photo1)): ?>
                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->photo1); ?>" width="250px"
                                            height="300px">
                                        <?php else: ?>
                                            <?php if(Storage::exists('public/'.$item->photo2)): ?>
                                            <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->photo2); ?>" width="250px"
                                                height="300px">
                                            <?php else: ?>
                                                <?php if(Storage::exists('public/'.$item->photo3)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->photo3); ?>" width="250px"
                                                    height="300px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/products/404.jpg" width="250px"
                                                height="300px">
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </a>
                                    <?php if($item->qty > 0): ?>
                                    <a class="aa-add-card-btn add-to-mycart" data-prod_id="<?php echo e($item->id); ?>" data-user_id="<?php echo e(Auth::id() ? Auth::id() : ''); ?>"
                                        href="javascript:void(0)">
                                        <span class="fa fa-shopping-cart"></span>
                                        เพิ่มไปยังรถเข็น
                                    </a>
                                    <?php else: ?>
                                    <a class="aa-add-card-btn" href="javascript:void(0)">
                                        <span class="far fa-times-circle"></span>
                                        Pre order
                                    </a>
                                    <?php endif; ?>
                                    <figcaption>
                                        <h4 class="aa-product-title">
                                            <a href="<?php echo e(url('product-detail?search='.$item->id)); ?>" target="_blank">
                                                <?php echo e($item->name); ?>

                                            </a>
                                        </h4>
                                        <span
                                            class="aa-product-price">฿<?php echo e(number_format($item->price - $item->disc,2)); ?></span>
                                        <?php if($item->disc > 0): ?>
                                        <span class="aa-product-price">
                                            <del>฿<?php echo e(number_format($item->price,2)); ?></del>
                                        </span>
                                        <?php endif; ?>
                                    </figcaption>
                                </figure>
                                <div class="aa-product-hvr-content">
                                    <a class="add-to-wishlist" data-prod_id="<?php echo e($item->id); ?>" data-user_id="<?php echo e(Auth::id() ? Auth::id() : ''); ?>" href="javascript:void(0)"
                                        data-toggle="tooltip" data-placement="top" title="Add to Wishlist">
                                        <span class="far fa-heart"></span>
                                    </a>
                                    <a class="add-to-likes" data-prod_id="<?php echo e($item->id); ?>" data-user_id="<?php echo e(Auth::id() ? Auth::id() : ''); ?>" href="javascript:void(0)"
                                        data-toggle="tooltip" data-placement="top" title="Like">
                                        <span class="far fa-thumbs-up"></span>
                                    </a>
                                    <a href="javascript:void(0)" data-toggle2="tooltip" data-placement="top"
                                        title="Quick View" data-toggle="modal" data-id="<?php echo e($item->id); ?>"
                                        id="ShowModelProduct">
                                        <span class="fas fa-search"></span>
                                    </a>
                                </div>
                                <!-- product badge -->
                                <?php if($item->hot == 1 && $item->disc == 0 && $item->qty > 0): ?>
                                <span class="aa-badge aa-hot">HOT!</span>
                                <?php elseif($item->hot == 0 && $item->disc > 0 && $item->qty > 0): ?>
                                <span class="aa-badge aa-sale">SALE!</span>
                                <?php elseif($item->hot == 0 && $item->disc == 0 && $item->qty == 0): ?>
                                <span class="aa-badge aa-sold-out">Sold Out!</span>
                                <?php elseif($item->hot == 1 && $item->disc > 0 && $item->qty > 0): ?>
                                <span class="aa-badge aa-hot">HOT!</span>
                                <span class="aa-badge aa-sale" style="margin-top: 35px">SALE!</span>
                                <?php elseif($item->hot == 1 && $item->disc == 0 && $item->qty == 0): ?>
                                <span class="aa-badge aa-hot">HOT!</span>
                                <span class="aa-badge aa-sold-out" style="margin-top: 35px">Sold Out!</span>
                                <?php elseif($item->hot == 0 && $item->disc > 0 && $item->qty == 0): ?>
                                <span class="aa-badge aa-sale">SALE!</span>
                                <span class="aa-badge aa-sold-out" style="margin-top: 35px">Sold Out!</span>
                                <?php elseif($item->hot == 1 && $item->disc > 0 && $item->qty == 0): ?>
                                <span class="aa-badge aa-sale">SALE!</span>
                                <span class="aa-badge aa-hot" style="margin-top: 35px">HOT!</span>
                                <span class="aa-badge aa-sold-out" style="margin-top: 70px">Sold Out!</span>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- start single product item -->
                        </ul>
                        <!-- quick view modal -->
                        <?php echo $__env->make('layouts.modal-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- / quick view modal -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- / product category -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dailyshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\pawarisashop\resources\views/product-detail.blade.php ENDPATH**/ ?>