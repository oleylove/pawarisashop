<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    รายละเอียดสินค้า รหัส : <?php echo e($product->id); ?>

                    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(session('fail')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('fail')); ?>

                    </div>
                    <?php endif; ?>

                </div>
                <div class="card-body">

                    <a href="<?php echo e(url('/product')); ?>" title="Back">
                        <button class="btn btn-warning btn-sm mr-2">
                            <i class="fas fa-undo" aria-hidden="true"></i>
                            กลับ
                        </button>
                    </a>
                    <a href="<?php echo e(url('/product/' . $product->id . '/edit')); ?>" title="Edit Product">
                        <button class="btn btn-primary btn-sm mr-2">
                            <i class="far fa-edit" aria-hidden="true"></i>
                            แก้ไข
                        </button>
                    </a>

                    <form method="POST" action="<?php echo e(url('product' . '/' . $product->id)); ?>" accept-charset="UTF-8"
                        style="display:inline">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="photo1" id="photo1" value="<?php echo e($product->photo1); ?>">
                        <input type="hidden" name="photo2" id="photo2" value="<?php echo e($product->photo2); ?>">
                        <input type="hidden" name="photo3" id="photo3" value="<?php echo e($product->photo3); ?>">
                        <button type="submit" class="btn btn-danger btn-sm" title="Delete Product"
                            onclick="return confirm(&quot;คุณแน่ใช่ใช่ไหมที่จะลบสินค้ารายการนี้ ? ยืนยัน&quot;)">
                            ยกเลิกขาย
                        </button>
                    </form>
                    <br />
                    <br />
                    <div class="row">
                        <div class="col-md">
                            <div class="table-responsive">
                                <table class="table table-striped table-sm">
                                    <tbody>
                                        <tr>
                                            <th width="150px"> ประเภทหลัก </th>
                                            <td> <?php echo e($product->category_sub->category->name); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> ประเภทย่อย </th>
                                            <td> <?php echo e($product->category_sub->name); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> ชื่อสินค้า </th>
                                            <td> <?php echo e($product->name); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> รายละเอียดสินค้า </th>
                                            <td> <?php echo e($product->title); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> ขนาดสินค้า </th>
                                            <td> <?php echo e($product->size); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> สีสินค้า </th>
                                            <td> <?php echo e($product->color); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> ราคาขาย </th>
                                            <td> <?php echo e(number_format($product->price,2) .' บาท'); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> ต้นทุน </th>
                                            <td> <?php echo e(number_format($product->cost,2) .' บาท'); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> ส่วนลด </th>
                                            <td> <?php echo e(number_format($product->disc,2) .' บาท'); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> จำนวนสินค้า </th>
                                            <td> <?php echo e($product->qty .' ชิ้น'); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> ขายไปแล้ว </th>
                                            <td> <?php echo e($product->sold .' ชิ้น'); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> สินค้ามาแรง </th>
                                            <td>
                                                <?php if($product->hot == 1): ?>
                                                แนะนำมาแรง
                                                <?php else: ?>
                                                ไม่แนะนำ
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> Vote </th>
                                            <td> <?php echo e($product->vote); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> Score </th>
                                            <td> <?php echo e($product->score); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> Rating </th>
                                            <td> <?php echo e($product->rating); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> เนื้อหาสินค้า </th>
                                            <td> <?php echo e($product->content); ?> </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="col-md">
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <th> รูปสินค้า 1 </th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$product->photo1)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo1); ?>"
                                                    class="rounded-lg border border-success" width="250px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/products/404.jpg"
                                                    class="rounded-lg border border-success" width="250px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> รูปสินค้า 2 </th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$product->photo2)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo2); ?>"
                                                    class="rounded-lg border border-success" width="250px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/products/404.jpg"
                                                    class="rounded-lg border border-success" width="250px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> รูปสินค้า 3 </th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$product->photo3)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo3); ?>"
                                                    class="rounded-lg border border-success" width="250px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/products/404.jpg"
                                                    class="rounded-lg border border-success" width="250px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\khaopanshop\resources\views/product/show.blade.php ENDPATH**/ ?>