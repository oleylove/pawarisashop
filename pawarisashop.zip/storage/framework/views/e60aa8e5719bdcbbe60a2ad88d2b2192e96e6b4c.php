<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md">
                            รายซื่อสมาชิกทั้งหมด
                        </div>
                        <div class="col-md">
                            <form method="GET" action="<?php echo e(url('/profile')); ?>" accept-charset="UTF-8"
                                class="form-inline my-2 my-lg-0 float-right" role="search">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="search" placeholder="Search..."
                                        value="<?php echo e(request('search')); ?>">
                                    <span class="input-group-append">
                                        <button class="btn btn-secondary" type="submit">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </span>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-striped">
                            <thead>
                                <tr>
                                    <th class="text-center">No.</th>
                                    <th>วันสมัค</th>
                                    <th>ชื่อ</th>
                                    <th>อีเมลล์</th>
                                    <th class="text-center">คำสั่งซื่อสินค้า</th>
                                    <th class="text-center">โหวตสินค้า</th>
                                    <th class="text-center">รีวิวสินค้า</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center">
                                        <?php echo e(($users ->currentpage()-1) * $users ->perpage() + $loop->index + 1); ?>

                                    </td>
                                    <td><?php echo e(get_dmY($item->created_at)); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td class="text-center"><?php echo e($item->orders->count() .' ครั้ง'); ?></td>
                                    <td class="text-center"><?php echo e($item->votes->count() .' ครั้ง'); ?></td>
                                    <td class="text-center"><?php echo e($item->reviews->count() .' ครั้ง'); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(url('/profile/' . $item->id)); ?>" title="View Profile"><button
                                                class="btn btn-info btn-sm">
                                                View
                                            </button>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="pagination-wrapper">
                            <?php echo $users->appends(['search' => Request::get('search')])->render(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\khaopanshop\resources\views/profile/index.blade.php ENDPATH**/ ?>