<?php $__env->startSection('title', 'KhaoPan Shop | Admin Config Web'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-9">
            <div class="card">
                <div class="card-header">แก้ไขข้อมูลร้าน</div>
                <div class="card-body">
                    <a href="<?php echo e(url('/config')); ?>" title="Back">
                        <button class="btn btn-warning btn-sm mr-2">
                            <i class="fas fa-undo" aria-hidden="true"></i>
                            Back
                        </button>
                    </a>
                    <br />
                    <br />

                    <?php if($errors->any()): ?>
                    <ul class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(url('/config/' . $config->id)); ?>" accept-charset="UTF-8"
                        class="form-horizontal was-validated" enctype="multipart/form-data">
                        <?php echo e(method_field('PATCH')); ?>

                        <?php echo e(csrf_field()); ?>


                        <div class="row">
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('ชื่อร้าน') ? 'has-error' : ''); ?>">
                                    <label for="title" class="control-label"><?php echo e('Title'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="title" type="text" id="title"
                                        value="<?php echo e(isset($config->title) ? $config->title : ''); ?>">
                                    <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('website') ? 'has-error' : ''); ?>">
                                    <label for="website" class="control-label"><?php echo e('Website'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="website" type="text" id="website"
                                        value="<?php echo e(isset($config->website) ? $config->website : ''); ?>">
                                    <?php echo $errors->first('website', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('facebook') ? 'has-error' : ''); ?>">
                                    <label for="facebook" class="control-label"><?php echo e('Facebook'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="facebook" type="text" id="facebook"
                                        value="<?php echo e(isset($config->facebook) ? $config->facebook : ''); ?>">
                                    <?php echo $errors->first('facebook', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('line') ? 'has-error' : ''); ?>">
                                    <label for="line" class="control-label"><?php echo e('Line'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="line" type="text" id="line"
                                        value="<?php echo e(isset($config->line) ? $config->line : ''); ?>">
                                    <?php echo $errors->first('line', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                                    <label for="address" class="control-label"><?php echo e('ที่อยู่ร้าน'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <textarea class="form-control" rows="3" name="address" type="textarea" id="address"
                                        required><?php echo e(isset($config->address) ? $config->address : ''); ?></textarea>
                                    <?php echo $errors->first('address', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('logo') ? 'has-error' : ''); ?>">
                                    <label for="logo" class="control-label"><?php echo e('Logo web'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="logo" type="file" id="logo"
                                        value="<?php echo e(isset($config->logo) ? $config->logo : ''); ?>">
                                    <?php echo $errors->first('logo', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="logo_old" id="logo_old"
                                        value="<?php echo e(isset($config->logo) ? $config->logo : 'logo'); ?>">
                                    <?php if(Storage::exists('public/'.$config->logo)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->logo); ?>"
                                        class="rounded-lg border border-success mt-1" width="50px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                        class="rounded-lg border border-success" width="50px">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('bbl_logo') ? 'has-error' : ''); ?>">
                                    <label for="bbl_logo" class="control-label"><?php echo e('Logo ธนาคารกรุงเทพ'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="bbl_logo" type="file" id="bbl_logo"
                                        value="<?php echo e(isset($config->bbl_logo) ? $config->bbl_logo : ''); ?>">
                                    <?php echo $errors->first('bbl_logo', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="bbl_logo_old" id="bbl_logo_old"
                                        value="<?php echo e(isset($config->bbl_logo) ? $config->bbl_logo : 'bbl_logo'); ?>">
                                    <?php if(Storage::exists('public/'.$config->bbl_logo)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->bbl_logo); ?>"
                                        class="rounded-lg border border-success mt-1" width="90px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                        class="rounded-lg border border-success" width="90px">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('kbsnk_logo') ? 'has-error' : ''); ?>">
                                    <label for="kbsnk_logo" class="control-label"><?php echo e('Logo ธนาคารกสิกรไทย'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="kbsnk_logo" type="file" id="kbsnk_logo"
                                        value="<?php echo e(isset($config->kbsnk_logo) ? $config->kbsnk_logo : ''); ?>">
                                    <?php echo $errors->first('kbsnk_logo', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="kbsnk_logo_old" id="kbsnk_logo_old"
                                        value="<?php echo e(isset($config->kbsnk_logo) ? $config->kbsnk_logo : 'kbsnk_logo'); ?>">
                                    <?php if(Storage::exists('public/'.$config->kbsnk_logo)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->kbsnk_logo); ?>"
                                        class="rounded-lg border border-success mt-1" width="90px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                        class="rounded-lg border border-success" width="90px">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('scb_logo') ? 'has-error' : ''); ?>">
                                    <label for="scb_logo" class="control-label"><?php echo e('Logo ธนาคารไทยพาณิชย์'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="scb_logo" type="file" id="scb_logo"
                                        value="<?php echo e(isset($config->scb_logo) ? $config->scb_logo : ''); ?>">
                                    <?php echo $errors->first('scb_logo', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="scb_logo_old" id="scb_logo_old"
                                        value="<?php echo e(isset($config->scb_logo) ? $config->scb_logo : 'scb_logo'); ?>">
                                    <?php if(Storage::exists('public/'.$config->scb_logo)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->scb_logo); ?>"
                                        class="rounded-lg border border-success mt-1" width="90px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                        class="rounded-lg border border-success" width="90px">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('bay_logo') ? 'has-error' : ''); ?>">
                                    <label for="bay_logo" class="control-label"><?php echo e('Logo ธนาคารกรุงศรี'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="bay_logo" type="file" id="bay_logo"
                                        value="<?php echo e(isset($config->bay_logo) ? $config->bay_logo : ''); ?>">
                                    <?php echo $errors->first('bay_logo', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="bay_logo_old" id="bay_logo_old"
                                        value="<?php echo e(isset($config->bay_logo) ? $config->bay_logo : 'bay_logo'); ?>">
                                    <?php if(Storage::exists('public/'.$config->bay_logo)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->bay_logo); ?>"
                                        class="rounded-lg border border-success mt-1" width="90px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                        class="rounded-lg border border-success" width="90px">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('bbl') ? 'has-error' : ''); ?>">
                                    <label for="bbl" class="control-label"><?php echo e('บัญชีธนาคารกรุงเทพ'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="bbl" type="text" id="bbl"
                                        value="<?php echo e(isset($config->bbl) ? $config->bbl : ''); ?>">
                                    <?php echo $errors->first('bbl', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('kbsnk') ? 'has-error' : ''); ?>">
                                    <label for="kbsnk" class="control-label"><?php echo e('บัญชีกสิกรไทย'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="kbsnk" type="text" id="kbsnk"
                                        value="<?php echo e(isset($config->kbsnk) ? $config->kbsnk : ''); ?>">
                                    <?php echo $errors->first('kbsnk', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('scb') ? 'has-error' : ''); ?>">
                                    <label for="scb" class="control-label"><?php echo e('บัญชีไทยพาณิชย์'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="scb" type="text" id="scb"
                                        value="<?php echo e(isset($config->scb) ? $config->scb : ''); ?>">
                                    <?php echo $errors->first('scb', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('bay') ? 'has-error' : ''); ?>">
                                    <label for="bay" class="control-label"><?php echo e('บัญชีกรุงศรี'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="bay" type="text" id="bay"
                                        value="<?php echo e(isset($config->bay) ? $config->bay : ''); ?>">
                                    <?php echo $errors->first('bay', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo1') ? 'has-error' : ''); ?>">
                                    <label for="photo1" class="control-label"><?php echo e('รูปสไลด์โชว์-1 ขนาด 1920x700'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="photo1" type="file" id="photo1"
                                        value="<?php echo e(isset($config->photo1) ? $config->photo1 : ''); ?>">
                                    <?php echo $errors->first('photo1', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="photo1_old" id="photo1_old"
                                        value="<?php echo e(isset($config->photo1) ? $config->photo1 : 'photo1'); ?>">
                                    <?php if(Storage::exists('public/'.$config->photo1)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo1); ?>"
                                        class="rounded-lg border border-success mt-1" width="290px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                        class="rounded-lg border border-success" width="290px">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo2') ? 'has-error' : ''); ?>">
                                    <label for="photo2" class="control-label"><?php echo e('รูปสไลด์โชว์-2 ขนาด 1920x700'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="photo2" type="file" id="photo2"
                                        value="<?php echo e(isset($config->photo2) ? $config->photo2 : ''); ?>">
                                    <?php echo $errors->first('photo2', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="photo2_old" id="photo2_old"
                                        value="<?php echo e(isset($config->photo2) ? $config->photo2 : 'photo2'); ?>">
                                    <?php if(Storage::exists('public/'.$config->photo2)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo2); ?>"
                                        class="rounded-lg border border-success mt-1" width="290px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                        class="rounded-lg border border-success" width="290px">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo3') ? 'has-error' : ''); ?>">
                                    <label for="photo3" class="control-label"><?php echo e('รูปสไลด์โชว์-3 ขนาด 1920x700'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="photo3" type="file" id="photo3"
                                        value="<?php echo e(isset($config->photo3) ? $config->photo3 : ''); ?>">
                                    <?php echo $errors->first('photo3', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="photo3_old" id="photo3_old"
                                        value="<?php echo e(isset($config->photo3) ? $config->photo3 : 'photo3'); ?>">
                                    <?php if(Storage::exists('public/'.$config->photo3)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo3); ?>"
                                        class="rounded-lg border border-success mt-1" width="290px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                        class="rounded-lg border border-success" width="290px">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo4') ? 'has-error' : ''); ?>">
                                    <label for="photo4" class="control-label"><?php echo e('รูปสไลด์โชว์-4 ขนาด 1920x700'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="photo4" type="file" id="photo4"
                                        value="<?php echo e(isset($config->photo4) ? $config->photo4 : ''); ?>">
                                    <?php echo $errors->first('photo4', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="photo4_old" id="photo4_old"
                                        value="<?php echo e(isset($config->photo4) ? $config->photo4 : 'photo4'); ?>">
                                    <?php if(Storage::exists('public/'.$config->photo4)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo4); ?>"
                                        class="rounded-lg border border-success mt-1" width="290px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                        class="rounded-lg border border-success" width="290px">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo5') ? 'has-error' : ''); ?>">
                                    <label for="photo5" class="control-label"><?php echo e('รูปสไลด์โชว์-5 ขนาด 1920x700'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="photo5" type="file" id="photo5"
                                        value="<?php echo e(isset($config->photo5) ? $config->photo5 : ''); ?>">
                                    <?php echo $errors->first('photo5', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="photo5_old" id="photo5_old"
                                        value="<?php echo e(isset($config->photo5) ? $config->photo5 : 'photo5'); ?>">
                                    <?php if(Storage::exists('public/'.$config->photo5)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo5); ?>"
                                        class="rounded-lg border border-success mt-1" width="290px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                        class="rounded-lg border border-success" width="290px">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo6') ? 'has-error' : ''); ?>">
                                    <label for="photo6" class="control-label"><?php echo e('รูปสไลด์โชว์-6 ขนาด 1920x700'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="photo6" type="file" id="photo6"
                                        value="<?php echo e(isset($config->photo6) ? $config->photo6 : ''); ?>">
                                    <?php echo $errors->first('photo6', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="photo6_old" id="photo6_old"
                                        value="<?php echo e(isset($config->photo6) ? $config->photo6 : 'photo6'); ?>">
                                    <?php if(Storage::exists('public/'.$config->photo6)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo6); ?>"
                                        class="rounded-lg border border-success mt-1" width="290px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                        class="rounded-lg border border-success" width="290px">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <input class="btn btn-primary" type="submit" value="<?php echo e('Update'); ?>">
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/config/edit.blade.php ENDPATH**/ ?>