<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-10">
            <div class="card">
                <div class="card-header">รายการสินค้าคำสั่งซื่อ # <?php echo e($po_id); ?></div>
                <div class="card-body">

                    <a href="<?php echo e(url('/order')); ?>" title="Back">
                        <button class="btn btn-warning btn-sm">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i>
                            Back
                        </button>
                    </a>

                    <form method="GET" action="<?php echo e(url('/order-product')); ?>" accept-charset="UTF-8"
                        class="form-inline my-2 my-lg-0 float-right" role="search">
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search..."
                                value="<?php echo e(request('search')); ?>">
                            <span class="input-group-append">
                                <button class="btn btn-secondary" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                    </form>

                    <br />
                    <br />
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr class="text-center">
                                    <th>ลำดับ</th>
                                    <th class="text-left">สินค้า</th>
                                    <th>ราคา</th>
                                    <th>จำนวน</th>
                                    <th>ราคารวม</th>
                                    <th>ส่วนลด</th>
                                    <th>จ่ายสุทธิ</th>
                                    <th>สถานะ</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orderproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td class="text-left"><?php echo e($item->product->title); ?></td>
                                    <td><?php echo e(number_format($item->product->price,2)); ?></td>
                                    <td><?php echo e($item->qty); ?></td>
                                    <td><?php echo e(number_format($item->price,2)); ?></td>
                                    <td><?php echo e(number_format($item->disc,2)); ?></td>
                                    <td><?php echo e(number_format($item->net,2)); ?></td>
                                    <td><?php echo e($item->order->status); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('/order-product/' . $item->id)); ?>" title="View OrderProduct">
                                            <button class="btn btn-info btn-sm">
                                                View
                                            </button>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="pagination-wrapper"> <?php echo $orderproduct->appends(['search' =>
                            Request::get('search')])->render(); ?> </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/order-product/index.blade.php ENDPATH**/ ?>