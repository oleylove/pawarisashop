<?php $__env->startSection('title','KhaoPan Shop | Product'); ?>

<?php $__env->startSection('content'); ?>

<!-- product category -->
<section id="aa-product-category">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-9 col-sm-8 col-md-push-3">
                <div class="aa-product-catg-content">
                    <div class="aa-product-catg-head">
                        <div class="aa-product-catg-head-left">
                            <form action="" class="aa-sort-form">
                                <label for="">Sort by</label>
                                <select name="">
                                    <option value="1" selected="Default">Default</option>
                                    <option value="2">Name</option>
                                    <option value="3">Price</option>
                                    <option value="4">Date</option>
                                </select>
                            </form>
                            <form action="" class="aa-show-form">
                                <label for="">Show</label>
                                <select name="">
                                    <option value="1" selected="12">12</option>
                                    <option value="2">24</option>
                                    <option value="3">36</option>
                                </select>
                            </form>
                        </div>
                        <div class="aa-product-catg-head-right">
                            <a id="grid-catg" href="javascript:void(0)"><span class="fa fa-th"></span></a>
                            <a id="list-catg" href="javascript:void(0)"><span class="fa fa-list"></span></a>
                        </div>
                    </div>
                    <div class="aa-product-catg-body">
                        <ul class="aa-product-catg">
                            <!-- start single product item -->
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <figure>
                                    <a class="aa-product-img" href="<?php echo e(url('product-detail?search='.$item->id)); ?>"
                                        target="_bank">
                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->photo1); ?>" alt="polo shirt img">
                                    </a>
                                    <?php if($item->qty > 0): ?>
                                    <a class="aa-add-card-btn add-to-mycart" id="<?php echo e($item->id); ?>" href="javascript:void(0)">
                                        <span class="fa fa-shopping-cart"></span>
                                        เพิ่มไปยังรถเข็น
                                    </a>
                                    <?php else: ?>
                                    <a class="aa-add-card-btn" href="javascript:void(0)" onclick="return alert(&quot;สินค้าหมดคะ!&quot;)">
                                        <span class="far fa-times-circle"></span>
                                        Pre order
                                    </a>
                                    <?php endif; ?>
                                    <figcaption>
                                        <h4 class="aa-product-title">
                                            <a href="<?php echo e(url('product-detail?search='.$item->id)); ?>"
                                                target="_blank"><?php echo e($item->name); ?>

                                            </a>
                                        </h4>
                                        <span class="aa-product-price">฿<?php echo e(number_format($item->price - $item->disc,2)); ?></span>
                                        <?php if($item->disc > 0): ?>
                                        <span class="aa-product-price">
                                            <del>฿<?php echo e(number_format($item->price,2)); ?></del>
                                        </span>
                                        <?php endif; ?>
                                        <p class="aa-product-descrip">
                                            <?php echo e($item->title); ?>

                                        </p>
                                    </figcaption>
                                </figure>
                                <div class="aa-product-hvr-content">
                                    <a class="add-to-wishlist" id="<?php echo e($item->id); ?>" href="javascript:void(0)"
                                        data-toggle="tooltip" data-placement="top" title="Add to Wishlist">
                                        <span class="far fa-heart"></span>
                                    </a>
                                    <a href="javascript:void(0)" data-toggle="tooltip" data-placement="top"
                                        title="Compare">
                                        <span class="far fa-thumbs-up"></span>
                                    </a>
                                    <a href="javascript:void(0)" data-toggle2="tooltip" data-placement="top"
                                        title="Quick View" data-toggle="modal" data-id="<?php echo e($item->id); ?>"
                                        id="ShowModelProduct">
                                        <span class="fas fa-search"></span>
                                    </a>
                                </div>
                                <!-- product badge -->
                                <?php if($item->hot == 1 && $item->disc == 0 && $item->qty > 0): ?>
                                <span class="aa-badge aa-hot">HOT!</span>
                                <?php elseif($item->hot == 0 && $item->disc > 0 && $item->qty > 0): ?>
                                <span class="aa-badge aa-sale">SALE!</span>
                                <?php elseif($item->hot == 0 && $item->disc == 0 && $item->qty == 0): ?>
                                <span class="aa-badge aa-sold-out">Sold Out!</span>
                                <?php elseif($item->hot == 1 && $item->disc > 0 && $item->qty > 0): ?>
                                <span class="aa-badge aa-hot">HOT!</span>
                                <span class="aa-badge aa-sale" style="margin-top: 35px">SALE!</span>
                                <?php elseif($item->hot == 1 && $item->disc == 0 && $item->qty == 0): ?>
                                <span class="aa-badge aa-hot">HOT!</span>
                                <span class="aa-badge aa-sold-out" style="margin-top: 35px">Sold Out!</span>
                                <?php elseif($item->hot == 0 && $item->disc > 0 && $item->qty == 0): ?>
                                <span class="aa-badge aa-sale">SALE!</span>
                                <span class="aa-badge aa-sold-out" style="margin-top: 35px">Sold Out!</span>
                                <?php elseif($item->hot == 1 && $item->disc > 0 && $item->qty == 0): ?>
                                <span class="aa-badge aa-sale">SALE!</span>
                                <span class="aa-badge aa-hot" style="margin-top: 35px">HOT!</span>
                                <span class="aa-badge aa-sold-out" style="margin-top: 70px">Sold Out!</span>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                        <!-- quick view modal -->
                            <?php echo $__env->make('layouts.modal-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- / quick view modal -->


                    </div>

                    <div class="aa-product-catg-pagination">
                        <nav>
                            <?php echo $products->appends(['category' => Request::get('category')])->render(); ?>

                        </nav>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-4 col-md-pull-9">
                <aside class="aa-sidebar">
                    <!-- single sidebar -->
                    <div class="aa-sidebar-widget">
                        <h3>Category</h3>
                        <ul class="aa-catg-nav">
                            <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(url('products?category='.$item->id.'&name='.$item->name)); ?>">
                                    <?php echo e($item->name); ?>

                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <!-- single sidebar -->
                    <div class="aa-sidebar-widget">
                        <h3>Tags</h3>
                        <div class="tag-cloud">
                            <?php $__currentLoopData = $cat_sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a
                                href=<?php echo e(url('products?category_sub='.$item->id.'&name='.$item->name)); ?>><?php echo e($item->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <!-- single sidebar -->
                    <div class="aa-sidebar-widget">
                        <h3>Shop By Price</h3>
                        <!-- price range -->
                        <div class="aa-sidebar-price-range">
                            <form action="">
                                <div id="skipstep" class="noUi-target noUi-ltr noUi-horizontal noUi-background">
                                </div>
                                <span id="skip-value-lower" class="example-val">30.00</span>
                                <span id="skip-value-upper" class="example-val">100.00</span>
                                <button class="aa-filter-btn" type="submit">Filter</button>
                            </form>
                        </div>

                    </div>
                    <!-- single sidebar -->
                    <div class="aa-sidebar-widget">
                        <h3>Shop By Color</h3>
                        <div class="aa-color-tag">
                            <a class="aa-color-green" href="javascript:void(0)"></a>
                            <a class="aa-color-yellow" href="javascript:void(0)"></a>
                            <a class="aa-color-pink" href="javascript:void(0)"></a>
                            <a class="aa-color-purple" href="javascript:void(0)"></a>
                            <a class="aa-color-blue" href="javascript:void(0)"></a>
                            <a class="aa-color-orange" href="javascript:void(0)"></a>
                            <a class="aa-color-gray" href="javascript:void(0)"></a>
                            <a class="aa-color-black" href="javascript:void(0)"></a>
                            <a class="aa-color-white" href="javascript:void(0)"></a>
                            <a class="aa-color-cyan" href="javascript:void(0)"></a>
                            <a class="aa-color-olive" href="javascript:void(0)"></a>
                            <a class="aa-color-orchid" href="javascript:void(0)"></a>
                        </div>
                    </div>
                    <!-- single sidebar -->
                    <div class="aa-sidebar-widget">
                        <h3>Recently Views</h3>
                        <div class="aa-recently-views">
                            <ul>
                                <li>
                                    <a href="javascript:void(0)" class="aa-cartbox-img"><img alt="img"
                                            src="<?php echo e(url('/')); ?>/storage/img/woman-small-2.jpg"></a>
                                    <div class="aa-cartbox-info">
                                        <h4><a href="javascript:void(0)">Product Name</a></h4>
                                        <p>1 x $250</p>
                                    </div>
                                </li>
                                <li>
                                    <a href="javascript:void(0)" class="aa-cartbox-img"><img alt="img"
                                            src="<?php echo e(url('/')); ?>/storage/img/woman-small-1.jpg"></a>
                                    <div class="aa-cartbox-info">
                                        <h4><a href="javascript:void(0)">Product Name</a></h4>
                                        <p>1 x $250</p>
                                    </div>
                                </li>
                                <li>
                                    <a href="javascript:void(0)" class="aa-cartbox-img"><img alt="img"
                                            src="<?php echo e(url('/')); ?>/storage/img/woman-small-2.jpg"></a>
                                    <div class="aa-cartbox-info">
                                        <h4><a href="javascript:void(0)">Product Name</a></h4>
                                        <p>1 x $250</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- single sidebar -->
                    <div class="aa-sidebar-widget">
                        <h3>Top Rated Products</h3>
                        <div class="aa-recently-views">
                            <ul>
                                <li>
                                    <a href="javascript:void(0)" class="aa-cartbox-img"><img alt="img"
                                            src="<?php echo e(url('/')); ?>/storage/img/woman-small-2.jpg"></a>
                                    <div class="aa-cartbox-info">
                                        <h4><a href="javascript:void(0)">Product Name</a></h4>
                                        <p>1 x $250</p>
                                    </div>
                                </li>
                                <li>
                                    <a href="javascript:void(0)" class="aa-cartbox-img"><img alt="img"
                                            src="<?php echo e(url('/')); ?>/storage/img/woman-small-1.jpg"></a>
                                    <div class="aa-cartbox-info">
                                        <h4><a href="javascript:void(0)">Product Name</a></h4>
                                        <p>1 x $250</p>
                                    </div>
                                </li>
                                <li>
                                    <a href="javascript:void(0)" class="aa-cartbox-img"><img alt="img"
                                            src="<?php echo e(url('/')); ?>/storage/img/woman-small-2.jpg"></a>
                                    <div class="aa-cartbox-info">
                                        <h4><a href="javascript:void(0)">Product Name</a></h4>
                                        <p>1 x $250</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    </div>
</section>
<!-- / product category -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dailyshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/product.blade.php ENDPATH**/ ?>