<?php $__env->startSection('title','Pawarisa Shop | Wishlist'); ?>

<?php $__env->startSection('content'); ?>

<!-- Cart view section -->
<section id="cart-view">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="cart-view-area">
                    <div class="cart-view-table aa-wishlist-table">
                        <?php if($wishlist->count()): ?>
                        <form action="">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>ลำดับ</th>
                                            <th>สินค้า</th>
                                            <th>ราคา</th>
                                            <th>จำนวนที่มี</th>
                                            <th>รูปสินค้า</th>
                                            <th>เพิ่มไปยังรถเข็น</th>
                                            <th>ยกเลิก</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td>
                                                <a class="aa-cart-title" href="javascript:void(0)"><?php echo e($item->product->name); ?></a>
                                            </td>
                                            <td>
                                                <?php echo e(number_format($item->product->price - $item->product->disc,2)); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->product->qty); ?>

                                            </td>
                                            <td>
                                                <a href="javascript:void(0)">
                                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->product->photo1); ?>" alt="img">
                                                </a>
                                            </td>
                                            <td>
                                                

                                                <a class="aa-add-to-cart-btn add-to-mycart" data-prod_id="<?php echo e($item->prod_id); ?>"
                                                    data-user_id="<?php echo e(Auth::id() ? Auth::id() : ''); ?>" href="javascript:void(0)">
                                                    <span class="fa fa-shopping-cart" style="font-size: 24px;"></span>
                                                </a>
                                            </td>
                                            <td>
                                                <a class="remove" href="<?php echo e(url('mywishlist-delete/'. $item->id)); ?>" >
                                                    <i class="far fa-times-circle" style="font-size: 24px;"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                        <?php else: ?>
                        <div class="col-md text-center" style="margin-top: 50px;">
                            <a href="<?php echo e(url('home')); ?>" class="aa-browse-btn">เลือกชื้อสินค้า</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- / Cart view section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dailyshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\khaopanshop\resources\views/wishlist.blade.php ENDPATH**/ ?>