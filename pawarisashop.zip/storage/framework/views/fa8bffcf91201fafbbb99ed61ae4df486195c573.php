<?php $__env->startSection('title', 'Khao Pan-Shop | Admin Config Web'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-9">
            <div class="card">
                <div class="card-header">ข้อมูลร้าน</div>
                <div class="card-body">
                    <a href="<?php echo e(url('/config/' . $config->id . '/edit')); ?>" title="Edit config">
                        <button class="btn btn-primary btn-sm mr-2">
                            <i class="far fa-edit" aria-hidden="true"></i>
                            Edit
                        </button>
                    </a>
                    <br />
                    <br />
                    <div class="row">
                        <div class="col-md">
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <th width="150px"> ชื่อร้าน </th>
                                            <td> <?php echo e($config->title); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> Facebook </th>
                                            <td> <?php echo e($config->facebook); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> ที่อยู่ร้าน </th>
                                            <td> <?php echo e($config->address); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> บัญชีธนาคารกรุงเทพ </th>
                                            <td> <?php echo e($config->bbl); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> บัญชีธนาคารกสิกรไทย </th>
                                            <td> <?php echo e($config->kbsnk); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> บัญชีธนาคารไทยพาณิชย์ </th>
                                            <td> <?php echo e($config->scb); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> บัญชีธนาคารกรุงศรี </th>
                                            <td> <?php echo e($config->bay); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> รูปสไลด์โชว์-1 ขนาด 1920x700</th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$config->photo1)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo1); ?>"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> รูปสไลด์โชว์-2 ขนาด 1920x700 </th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$config->photo2)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo2); ?>"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> รูปสไลด์โชว์-3 ขนาด 1920x700</th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$config->photo3)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo3); ?>"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                        <div class="col-md">
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <th width="150px"> Website </th>
                                            <td> <?php echo e($config->website); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> Line </th>
                                            <td> <?php echo e($config->line); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> Logo ร้าน</th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$config->logo)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->logo); ?>"
                                                    class="rounded-lg border border-success" width="50px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                                    class="rounded-lg border border-success" width="50px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> Logo ธนาคารกรุงเทพ </th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$config->bbl_logo)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->bbl_logo); ?>"
                                                    class="rounded-lg border border-success" width="50px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                                    class="rounded-lg border border-success" width="50px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> Logo ธนาคารกสิกรไทย </th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$config->kbsnk_logo)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->kbsnk_logo); ?>"
                                                    class="rounded-lg border border-success" width="50px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                                    class="rounded-lg border border-success" width="50px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> Logo ธนาคารไทยพาณิชย์ </th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$config->scb_logo)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->scb_logo); ?>"
                                                    class="rounded-lg border border-success" width="50px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                                    class="rounded-lg border border-success" width="50px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> Logo ธนาคารกรุงศรี</th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$config->bay_logo)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->bay_logo); ?>"
                                                    class="rounded-lg border border-success" width="50px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                                    class="rounded-lg border border-success" width="50px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> รูปสไลด์โชว์-4 ขนาด 1920x700</th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$config->photo4)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo4); ?>"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> รูปสไลด์โชว์-5 ขนาด 1920x700</th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$config->photo5)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo5); ?>"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th> รูปสไลด์โชว์-6 ขนาด 1920x700</th>
                                            <td>
                                                <?php if(Storage::exists('public/'.$config->photo6)): ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->photo6); ?>"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/storage/config/404.png"
                                                    class="rounded-lg border border-success" width="200px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\khaopanshop\resources\views/config/index.blade.php ENDPATH**/ ?>