<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    ราการคำสั่งซื้อสินค้าทั้งหมดของร้าน
                    <?php if(session('alert')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('alert')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-9">
                            <a href="<?php echo e(url('/order')); ?>" class="btn btn-info mr-2 mb-2"
                                title="ทั้งหมด">
                                ทั้งหมด
                            </a>

                            <a href="<?php echo e(url('/order?search=รอตรวจสอบ')); ?>" class="btn btn-warning mr-2 mb-2"
                                title="รอตรวจสอบ">
                                รอตรวจสอบ
                            </a>
                            <a href="<?php echo e(url('/order?search=รอจัดส่ง')); ?>" class="btn btn-danger mr-2 mb-2"
                                title="รอจัดส่ง">
                                รอจัดส่ง
                            </a>
                            <a href="<?php echo e(url('/order?search=จัดส่งแล้ว')); ?>" class="btn btn-primary mr-2 mb-2"
                                title="จัดส่งแล้ว">
                                จัดส่งแล้ว
                            </a>
                            <a href="<?php echo e(url('/order?search=ได้รับสินค้าแล้ว')); ?>" class="btn btn-success mr-2 mb-2"
                                title="ได้รับสินค้าแล้ว">
                                ได้รับสินค้าแล้ว
                            </a>
                            <a href="<?php echo e(url('/order?search=ยกเลิก')); ?>" class="btn btn-secondary mb-2" title="ยกเลิก">
                                ยกเลิก
                            </a>
                        </div>
                        <div class="col-md-3">
                            <form method="GET" action="<?php echo e(url('/order')); ?>" accept-charset="UTF-8"
                                class="form-inline my-2 my-lg-0 float-right" role="search">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="search" placeholder="Search..."
                                        value="<?php echo e(request('search')); ?>">
                                    <span class="input-group-append">
                                        <button class="btn btn-secondary" type="submit">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </span>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-sm" id="dataOrder">
                            <thead>
                                <tr class="text-center">
                                    <th>ลำดับ</th>
                                    <th>รหัส</th>
                                    <th>เวลาสั่งซื้อ</th>
                                    <th>ยอดรวม</th>
                                    <th>สถานะคำสั่งซื้อ</th>
                                    <th>เลขพัสดุ</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td>
                                        <?php echo e(($order ->currentpage()-1) * $order ->perpage() + $loop->index + 1); ?>

                                    </td>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->paid_at); ?></td>
                                    <td><?php echo e(number_format($item->net,2)); ?></td>
                                    <td>
                                        <?php switch($item->status):
                                        case ('รอตรวจสอบ'): ?>
                                        <button type="button" class="btn btn-warning btn-sm" data-id="<?php echo e($item->id); ?>"
                                            id="slipOrder" data-img="<?php echo e($item->slip); ?>" data-netpay="<?php echo e($item->net); ?>"
                                            data-status="<?php echo e($item->status); ?>">
                                            <?php echo e($item->status); ?>

                                        </button>
                                        <div class="spinner-border text-warning spinner-border-sm" role="status"></div>
                                        <?php break; ?>
                                        <?php case ('รอจัดส่ง'): ?>
                                        <button type="button" class="btn btn-danger btn-sm" data-id="<?php echo e($item->id); ?>"
                                            id="slipOrder" data-img="<?php echo e($item->slip); ?>"
                                            data-status="<?php echo e($item->status); ?>">
                                            <?php echo e($item->status); ?>

                                        </button>
                                        <div class="spinner-border text-danger spinner-border-sm" role="status"></div>
                                        <?php break; ?>
                                        <?php case ('จัดส่งแล้ว'): ?>
                                        <button type="button" class="btn btn-primary btn-sm" data-id="<?php echo e($item->id); ?>"
                                            id="slipOrder" data-img="<?php echo e($item->slip); ?>"
                                            data-status="<?php echo e($item->status); ?>">
                                            <?php echo e($item->status); ?>

                                        </button>
                                        <div class="spinner-border text-primary spinner-border-sm" role="status"></div>
                                        <?php break; ?>
                                        <?php case ('ได้รับสินค้าแล้ว'): ?>
                                        <button type="button" class="btn btn-success btn-sm">
                                            <?php echo e($item->status); ?>

                                        </button>
                                        <?php break; ?>
                                        <?php case ('ยกเลิก'): ?>
                                        <button type="button" class="btn btn-secondary btn-sm">
                                            <?php echo e($item->status); ?>

                                        </button>
                                        <?php break; ?>
                                        <?php endswitch; ?>
                                    </td>
                                    <td><?php echo e($item->tracking); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(url('/order-product/' . $item->id)); ?>" title="View Order">
                                            <button class="btn btn-info btn-sm">
                                                ดูรายการ
                                            </button>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="pagination-wrapper">
                            <?php echo $order->appends(['search' => Request::get('search')])->render(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- modal sho slip order and confirm order -->
<?php echo $__env->make('admin.modal-slip-order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/order/index.blade.php ENDPATH**/ ?>