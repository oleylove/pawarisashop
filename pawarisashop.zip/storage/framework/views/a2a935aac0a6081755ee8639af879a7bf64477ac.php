<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-10">
            <div class="card">
                <div class="card-header">เพิ่มสินค้าใหม่ กรุณาใส่รายละเอียดสินค้าให้ถูกต้องและครบถ้วน</div>
                <div class="card-body">
                    <a href="<?php echo e(url('/product')); ?>" title="Back">
                        <button class="btn btn-warning btn-sm">
                            <i class="fas fa-undo" aria-hidden="true"></i>
                            Back
                        </button>
                    </a>
                    <br />
                    <br />

                    <?php if($errors->any()): ?>
                    <ul class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(url('/product')); ?>" accept-charset="UTF-8"
                        class="form-horizontal was-validated" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('catsub_id') ? 'has-error' : ''); ?>">
                                    <label for="catsub_id" class="control-label"><?php echo e('ประเภทย่อย'); ?></label>
                                    <select class="form-control" name="catsub_id" id="catsub_id" required>
                                        <option value="">เลือกประเภทย่อย</option>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php echo $errors->first('catsub_id', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <label for="name" class="control-label"><?php echo e('ชื่อสินค้า'); ?></label>
                                    <input class="form-control" name="name" type="text" id="name" required>
                                    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('hot') ? 'has-error' : ''); ?>">
                                    <label for="hot" class="control-label"><?php echo e('แนะนำ'); ?></label>
                                    <select class="form-control" name="hot" id="hot" required>
                                        <option value="">เลือก</option>
                                        <option value="1">แนะนำมาแรง</option>
                                        <option value="0">ไม่แนะนำ</option>
                                    </select>
                                    <?php echo $errors->first('hot', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('size') ? 'has-error' : ''); ?>">
                                    <label for="size" class="control-label"><?php echo e('ขนาด'); ?></label>
                                    <input class="form-control" name="size" type="text" id="size" required>
                                    <?php echo $errors->first('size', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                    <label for="title" class="control-label"><?php echo e('รายละเอียดสินค้า'); ?></label>
                                    <input class="form-control" name="title" type="text" id="title" required>
                                    <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

                                </div>

                            </div>
                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('color') ? 'has-error' : ''); ?>">
                                    <label for="color" class="control-label"><?php echo e('สี'); ?></label>
                                    <input class="form-control" name="color" type="text" id="color" required>
                                    <?php echo $errors->first('color', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('content') ? 'has-error' : ''); ?>">
                            <label for="content" class="control-label"><?php echo e('เนื้อหาสินค้า'); ?></label>
                            <textarea class="form-control" rows="5" name="content" type="textarea" id="content" required></textarea>
                            <?php echo $errors->first('content', '<p class="help-block">:message</p>'); ?>

                        </div>
                        <div class="row">
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
                                    <label for="price" class="control-label"><?php echo e('ราคาขาย'); ?></label>
                                    <input class="form-control" name="price" type="number" id="price" required>
                                    <?php echo $errors->first('price', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('cost') ? 'has-error' : ''); ?>">
                                    <label for="cost" class="control-label"><?php echo e('ต้นทุน'); ?></label>
                                    <input class="form-control" name="cost" type="number" id="cost" required>
                                    <?php echo $errors->first('cost', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('disc') ? 'has-error' : ''); ?>">
                                    <label for="disc" class="control-label"><?php echo e('ส่วนลด'); ?></label>
                                    <input class="form-control" name="disc" type="number" id="disc" required>
                                    <?php echo $errors->first('disc', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('qty') ? 'has-error' : ''); ?>">
                                    <label for="qty" class="control-label"><?php echo e('จำนวน'); ?></label>
                                    <input class="form-control" name="qty" type="number" id="qty" required>
                                    <?php echo $errors->first('qty', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo1') ? 'has-error' : ''); ?>">
                                    <label for="photo1" class="control-label"><?php echo e('รปู-1'); ?></label>
                                    <input class="form-control" name="photo1" type="file" id="photo1" required>
                                    <?php echo $errors->first('photo1', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo2') ? 'has-error' : ''); ?>">
                                    <label for="photo2" class="control-label"><?php echo e('รปู-2'); ?></label>
                                    <input class="form-control" name="photo2" type="file" id="photo2">
                                    <?php echo $errors->first('photo2', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo3') ? 'has-error' : ''); ?>">
                                    <label for="photo3" class="control-label"><?php echo e('รปู-3'); ?></label>
                                    <input class="form-control" name="photo3" type="file" id="photo3">
                                    <?php echo $errors->first('photo3', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <input class="btn btn-primary" type="submit" value="บันทึกข้อมูล">
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/product/create.blade.php ENDPATH**/ ?>