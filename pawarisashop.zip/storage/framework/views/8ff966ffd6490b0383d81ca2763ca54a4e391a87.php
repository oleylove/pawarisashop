<div class="row">
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('date') ? 'has-error' : ''); ?>">
            <label for="date" class="control-label"><?php echo e('วันที่'); ?></label>
            <input class="form-control" name="date" type="datetime-local" id="date"
                value="<?php echo e(isset($income->date) ? $income->date : ''); ?>" required>
            <?php echo $errors->first('date', '<p class="help-block">:message</p>'); ?>

        </div>

    </div>
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('income') ? 'has-error' : ''); ?>">
            <label for="income" class="control-label"><?php echo e('จำนวนเงิน'); ?></label>
            <input class="form-control" name="income" type="number" id="income"
                value="<?php echo e(isset($income->income) ? $income->income : ''); ?>" required>
            <?php echo $errors->first('income', '<p class="help-block">:message</p>'); ?>

        </div>

    </div>

</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('refer') ? 'has-error' : ''); ?>">
            <label for="refer" class="control-label"><?php echo e('หมายเหตุ'); ?></label>
            <select class="custom-select" id="refer" name="refer" required>
                <option value="">กรุณาเลือก...</option>
                <option value="รายรับ">รายรับ</option>
                <option value="รายจ่าย">รายจ่าย</option>
            </select>
            <?php echo $errors->first('refer', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('refer') ? 'has-error' : ''); ?>">
            <label for="refer" class="control-label"><?php echo e('หมายเหตุ'); ?></label>
            <input class="form-control" name="refer" type="text" id="refer"
                value="<?php echo e(isset($income->refer) ? $income->refer : ''); ?>" required>
            <?php echo $errors->first('refer', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <input class="btn btn-primary" type="submit"
                value="<?php echo e($formMode === 'create' ? 'บันทึกข้อมูล' : 'แก้ไขข้อมูล'); ?>">
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/income/form.blade.php ENDPATH**/ ?>