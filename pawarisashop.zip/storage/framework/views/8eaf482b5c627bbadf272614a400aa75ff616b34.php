<div class="col-md-6 col-sm-6 col-xs-12">
    <div class="aa-product-view-content">
        <h3 class="title-model"></h3>
        <div class="aa-price-block">
            <span class="aa-product-view-price"></span>
            <span class="aa-product-price"
                style="margin-left: 5px; color: tomato; text-decoration: line-through; font-size: 24px">
                <del></del>
            </span>
            <p class="aa-product-avilability"></p>
        </div>
        <p>ddddddddddddddddddddddddddd</p>
        <div class="row">
            <div class="col-md" style="display: inline-block">
                <h4>Size</h4>
                <div class="aa-prod-view-size">
                    <a href="javascript:void(0)" class="productsize"></a>
                </div>
            </div>
            <div class="col-md" style="display: inline-block">
                <h4>Size</h4>
                <div class="aa-prod-view-size">
                    <a href="javascript:void(0)" class="productcolor"></a>
                </div>
            </div>
        </div>
        <div class="aa-prod-quantity">
            <div class="aa-your-rating">
                <p id="VoteScoreRating"></p>
                <div class="barra-rating">
                    <span class="bg-rating"></span>
                    <span class="stars-rating">
                        <?php for($i=1; $i<=5; $i++): ?> <span class="star-rating">
                            <span class="starAbsolute-rating"
                                style="background-image: url(<?php echo e(url('/')); ?>/storage/starvote/starpng.png);">
                            </span>
                    </span>
                    <?php endfor; ?>
                    </span>
                </div>
            </div>
        </div>
        <div class="aa-prod-view-bottom">
            <a href="javascript:void(0)" class="aa-add-to-cart-btn"><span class="fa fa-shopping-cart"></span>Add To
                Cart</a>
            <a href="javascript:void(0)" class="aa-add-to-cart-btn">View
                Details</a>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/layouts/modal.blade.php ENDPATH**/ ?>