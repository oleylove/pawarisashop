<?php $__env->startSection('title','KhaoPan Shop | Error Page'); ?>

<?php $__env->startSection('content'); ?>

  <!-- 404 error section -->
  <section id="aa-error">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-error-area">
            <h2>404</h2>
            <span>Sorry! Page Not Found</span>
            <p>Sorry this content has been moved Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum, amet perferendis, nemo facere excepturi quis.</p>
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/home')); ?>"> Go to Homepage</a>
            <?php else: ?>
            <a href="<?php echo e(url('/')); ?>"> Go to Homepage</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- / 404 error section -->

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dailyshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\khaopanshop\resources\views/404.blade.php ENDPATH**/ ?>