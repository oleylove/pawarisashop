<div class="col-md-2">
    <div class="card">
        <div class="card-header">
            เมนูหลัก
        </div>

        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <li role="presentation" class="mb-2">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        Dashboard
                    </a>
                </li>
                <li role="presentation" class="mb-2">
                    <a href="<?php echo e(url('/order')); ?>">
                        คำสั่งซื้อสินค้า
                    </a>
                </li>
                <li role="presentation" class="mb-2">
                    <a href="<?php echo e(url('/product')); ?>">
                        รายการสินค้า
                    </a>
                </li>
                <li role="presentation" class="mb-2">
                    <a href="<?php echo e(url('/category')); ?>">
                        ประเภทสินค้า
                    </a>
                </li>
                <li role="presentation" class="mb-2">
                    <a href="<?php echo e(url('/profile')); ?>">
                        รายชื่อลูกค้า
                    </a>
                </li>
                <li role="presentation" class="mb-2">
                    <a href="<?php echo e(url('/income')); ?>">
                        บัญชีร้าน
                    </a>
                </li>

                <li role="presentation" class="mb-2">
                    <a href="<?php echo e(url('/config')); ?>">
                        ตั้งค่าเว็บ
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>