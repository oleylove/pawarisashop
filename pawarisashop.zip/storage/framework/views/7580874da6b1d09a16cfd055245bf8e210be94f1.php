<div class="form-group <?php echo e($errors->has('user_id') ? 'has-error' : ''); ?>">
    <label for="user_id" class="control-label"><?php echo e('User Id'); ?></label>
    <input class="form-control" name="user_id" type="number" id="user_id" value="<?php echo e(isset($orderproduct->user_id) ? $orderproduct->user_id : ''); ?>" >
    <?php echo $errors->first('user_id', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('prod_id') ? 'has-error' : ''); ?>">
    <label for="prod_id" class="control-label"><?php echo e('Prod Id'); ?></label>
    <input class="form-control" name="prod_id" type="number" id="prod_id" value="<?php echo e(isset($orderproduct->prod_id) ? $orderproduct->prod_id : ''); ?>" >
    <?php echo $errors->first('prod_id', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('po_id') ? 'has-error' : ''); ?>">
    <label for="po_id" class="control-label"><?php echo e('Po Id'); ?></label>
    <input class="form-control" name="po_id" type="number" id="po_id" value="<?php echo e(isset($orderproduct->po_id) ? $orderproduct->po_id : ''); ?>" >
    <?php echo $errors->first('po_id', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('qty') ? 'has-error' : ''); ?>">
    <label for="qty" class="control-label"><?php echo e('Qty'); ?></label>
    <input class="form-control" name="qty" type="number" id="qty" value="<?php echo e(isset($orderproduct->qty) ? $orderproduct->qty : ''); ?>" >
    <?php echo $errors->first('qty', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
    <label for="price" class="control-label"><?php echo e('Price'); ?></label>
    <input class="form-control" name="price" type="number" id="price" value="<?php echo e(isset($orderproduct->price) ? $orderproduct->price : ''); ?>" >
    <?php echo $errors->first('price', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('disc') ? 'has-error' : ''); ?>">
    <label for="disc" class="control-label"><?php echo e('Disc'); ?></label>
    <input class="form-control" name="disc" type="number" id="disc" value="<?php echo e(isset($orderproduct->disc) ? $orderproduct->disc : ''); ?>" >
    <?php echo $errors->first('disc', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('net') ? 'has-error' : ''); ?>">
    <label for="net" class="control-label"><?php echo e('Net'); ?></label>
    <input class="form-control" name="net" type="number" id="net" value="<?php echo e(isset($orderproduct->net) ? $orderproduct->net : ''); ?>" >
    <?php echo $errors->first('net', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/order-product/form.blade.php ENDPATH**/ ?>