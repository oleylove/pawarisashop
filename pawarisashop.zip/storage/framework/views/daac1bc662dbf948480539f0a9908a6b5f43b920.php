<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-10">
            <div class="card">
                <div class="card-header">ที่อยู่สำหรับจัดส่งของลูกค้ารหัส # <?php echo e($users->id); ?></div>
                <div class="card-body">

                    <a href="<?php echo e(url('/profile')); ?>" title="Back">
                        <button class="btn btn-warning btn-sm">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i>
                            Back
                        </button>
                    </a>
                    <br><br>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="table-responsive">
                                <table class="table table-borderless table-sm">
                                    <tbody>
                                        <tr>
                                            <th> ชื่อลูกค้า </th>
                                            <td> <?php echo e($users->name); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> อีเมลล์ </th>
                                            <td> <?php echo e($users->email); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> วันที่สมัคร </th>
                                            <td> <?php echo e($users->created_at); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> คำสั่งซื้อ </th>
                                            <td> <?php echo e($users->orders->count().' ครั้ง'); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> โหวต </th>
                                            <td> <?php echo e($users->votes->count().' ครั้ง'); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> รีวิวสินค้า </th>
                                            <td> <?php echo e($users->reviews->count().' ครั้ง'); ?> </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="table-responsive">
                                <table class="table table-sm table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">No.</th>
                                            <th>Name</th>
                                            <th>Phone</th>
                                            <th>Address</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center">
                                                <?php echo e($loop->iteration); ?>

                                            </td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->phone); ?></td>
                                            <td><?php echo e($item->address); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/profile/show.blade.php ENDPATH**/ ?>