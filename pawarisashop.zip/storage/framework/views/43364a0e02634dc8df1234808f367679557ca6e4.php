<div class="container">
    <div class="menu-area">
        <!-- Navbar -->
        <div class="navbar navbar-default" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="navbar-collapse collapse">
                <!-- Left nav -->
                <ul class="nav navbar-nav">
                    <?php if(auth()->guard()->check()): ?>
                    <li><a href="<?php echo e(url('/home')); ?>">หน้าแรก</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo e(url('/')); ?>">หน้าแรก</a></li>
                    <?php endif; ?>
                    <li><a href="<?php echo e(url('products')); ?>">กางเกงยีนส์แฟชั่น</a></li>
                    <li><a href="<?php echo e(url('contact-shop')); ?>">ติดต่อเรา</a></li>
                </ul>
            </div>
            <!--/.nav-collapse -->
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\ProjectsLaravel\pawarisashop\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>