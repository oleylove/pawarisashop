<?php if($formMode == 'edit'): ?>
    <div class="form-group<?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
        <label for="name" class="control-label"><?php echo e('ประเภท'); ?></label>
        <input class="form-control" name="name" type="text" id="name"
            value="<?php echo e(isset($category->name) ? $category->name : ''); ?>" readonly>
        <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

    </div>
<?php else: ?>
    <div class="form-group<?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
        <label for="name" class="control-label"><?php echo e('ประเภท'); ?></label>
        <input class="form-control" name="name" type="text" id="name"
            value="<?php echo e(isset($category->name) ? $category->name : ''); ?>">
        <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

    </div>
<?php endif; ?>
<div class="form-group <?php echo e($errors->has('sub_name') ? 'has-error' : ''); ?>">
    <label for="sub_name" class="control-label"><?php echo e('ประเภทย่อย'); ?></label>
    <input class="form-control" name="sub_name" type="text" id="sub_name"
        value="<?php echo e(isset($category->sub_name) ? $category->sub_name : ''); ?>">
    <?php echo $errors->first('sub_name', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/category/form.blade.php ENDPATH**/ ?>