<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Edit Product #<?php echo e($product->id); ?></div>
                <div class="card-body">
                    <a href="<?php echo e(url('/product')); ?>" title="Back">
                        <button class="btn btn-warning btn-sm">
                            <i class="fas fa-undo" aria-hidden="true"></i>
                            Back</button>
                    </a>
                    <br />
                    <br />

                    <?php if($errors->any()): ?>
                    <ul class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(url('/product/' . $product->id)); ?>" accept-charset="UTF-8"
                        class="form-horizontal was-validated" enctype="multipart/form-data">
                        <?php echo e(method_field('PATCH')); ?>

                        <?php echo e(csrf_field()); ?>


                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('catsub_id') ? 'has-error' : ''); ?>">
                                    <label for="catsub_id" class="control-label"><?php echo e('ประเภทย่อย'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <select class="form-control" name="catsub_id" id="catsub_id" required>
                                        <option value="<?php echo e($product->catsub_id); ?>"><?php echo e($product->category_sub->name); ?>

                                        </option>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php echo $errors->first('catsub_id', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <label for="name" class="control-label"><?php echo e('ชื่อสินค้า'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="name" type="text" id="name"
                                        value="<?php echo e(isset($product->name) ? $product->name : ''); ?>" required>
                                    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('hot') ? 'has-error' : ''); ?>">
                                    <label for="hot" class="control-label"><?php echo e('แนะนำ'); ?></label>
                                    <select class="form-control" name="hot" id="hot" required>
                                        <?php if(isset($product->hot)): ?>
                                            <?php switch($product->hot):
                                                case (0): ?>
                                                <option value="0">ไม่แนะนำ</option>
                                                <option value="1">แนะนำมาแรง</option>
                                                    <?php break; ?>
                                                <?php case (1): ?>
                                                <option value="1">แนะนำมาแรง</option>
                                                <option value="0">ไม่แนะนำ</option>
                                                    <?php break; ?>
                                            <?php endswitch; ?>
                                        <?php else: ?>
                                        <option value="">เลือก</option>
                                        <option value="1">แนะนำมาแรง</option>
                                        <option value="0">ไม่แนะนำ</option>
                                        <?php endif; ?>
                                    </select>
                                    <?php echo $errors->first('hot', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('size') ? 'has-error' : ''); ?>">
                                    <label for="size" class="control-label"><?php echo e('ขนาด'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="size" type="text" id="size"
                                        value="<?php echo e(isset($product->size) ? $product->size : ''); ?>" required>
                                    <?php echo $errors->first('size', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                    <label for="title" class="control-label"><?php echo e('รายละเอียดสินค้า'); ?></label>
                                    <input class="form-control" name="title" type="text" id="title"
                                        value="<?php echo e(isset($product->title) ? $product->title : ''); ?>" required>
                                    <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

                                </div>

                            </div>
                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('color') ? 'has-error' : ''); ?>">
                                    <label for="color" class="control-label"><?php echo e('สี'); ?></label>
                                    <input class="form-control" name="color" type="text" id="color"
                                        value="<?php echo e(isset($product->color) ? $product->color : ''); ?>" required>
                                    <?php echo $errors->first('color', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('content') ? 'has-error' : ''); ?>">
                            <label for="content" class="control-label"><?php echo e('เนื้อหาสินค้า'); ?></label>
                            <span class="text-danger"> *</span>
                            <textarea class="form-control" rows="5" name="content" type="textarea" id="content"
                                required><?php echo e(isset($product->content) ? $product->content : ''); ?></textarea>
                            <?php echo $errors->first('content', '<p class="help-block">:message</p>'); ?>

                        </div>

                        <div class="row">
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
                                    <label for="price" class="control-label"><?php echo e('ราคาขาย'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="price" type="number" id="price"
                                        value="<?php echo e(isset($product->price) ? $product->price : ''); ?>" required>
                                    <?php echo $errors->first('price', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('cost') ? 'has-error' : ''); ?>">
                                    <label for="cost" class="control-label"><?php echo e('ต้นทุน'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="cost" type="number" id="cost"
                                        value="<?php echo e(isset($product->cost) ? $product->cost : ''); ?>" readonly>
                                    <?php echo $errors->first('cost', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('disc') ? 'has-error' : ''); ?>">
                                    <label for="disc" class="control-label"><?php echo e('ส่วนลด'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="disc" type="number" id="disc"
                                        value="<?php echo e(isset($product->disc) ? $product->disc : 0); ?>" required>
                                    <?php echo $errors->first('disc', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('qty') ? 'has-error' : ''); ?>">
                                    <label for="qty" class="control-label"><?php echo e('จำนวน'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control" name="qty" type="number" id="qty"
                                        value="<?php echo e(isset($product->qty) ? $product->qty : 0); ?>" readonly>
                                    <?php echo $errors->first('qty', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo1') ? 'has-error' : ''); ?>">
                                    <label for="photo1" class="control-label"><?php echo e('รูปสินค้า-1'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control mb-1" name="photo1" type="file" id="photo1"
                                        value="<?php echo e(isset($product->photo1) ? $product->photo1 : ''); ?>">
                                    <?php echo $errors->first('photo1', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="photo1_old" id="photo1_old"
                                        value="<?php echo e(isset($product->photo1) ? $product->photo1 : 'photo1'); ?>">
                                    <?php if(Storage::exists('public/'.$product->photo1)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo1); ?>"
                                        class="rounded-lg border border-success mt-1" width="300px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/products/404.jpg"
                                        class="rounded-lg border border-success" width="300px">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo2') ? 'has-error' : ''); ?>">
                                    <label for="photo2" class="control-label"><?php echo e('รูปสินค้า-2'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control mb-1" name="photo2" type="file" id="photo2"
                                        value="<?php echo e(isset($product->photo2) ? $product->photo2 : ''); ?>">
                                    <?php echo $errors->first('photo2', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="photo2_old" id="photo2_old"
                                        value="<?php echo e(isset($product->photo2) ? $product->photo2 : 'photo2'); ?>">
                                    <?php if(Storage::exists('public/'.$product->photo2)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo2); ?>"
                                        class="rounded-lg border border-success mt-1" width="300px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/products/404.jpg"
                                        class="rounded-lg border border-success" width="300px">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group <?php echo e($errors->has('photo3') ? 'has-error' : ''); ?>">
                                    <label for="photo3" class="control-label"><?php echo e('รูปสินค้า-3'); ?></label>
                                    <span class="text-danger"> *</span>
                                    <input class="form-control mb-1" name="photo3" type="file" id="photo3"
                                        value="<?php echo e(isset($product->photo3) ? $product->photo3 : ''); ?>">
                                    <?php echo $errors->first('photo3', '<p class="help-block">:message</p>'); ?>

                                    <input type="hidden" name="photo3_old" id="photo3_old"
                                        value="<?php echo e(isset($product->photo3) ? $product->photo3 : 'photo3'); ?>">
                                    <?php if(Storage::exists('public/'.$product->photo3)): ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($product->photo3); ?>"
                                        class="rounded-lg border border-success mt-1" width="300px">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('/')); ?>/storage/products/404.jpg"
                                        class="rounded-lg border border-success" width="300px">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <input class="btn btn-primary" type="submit" value="แก้ไขข้อมูล">
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/product/edit.blade.php ENDPATH**/ ?>