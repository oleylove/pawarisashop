<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-9">
            <div class="card">
                <div class="card-header">รายละเอียดปรถเภท รหัส : <?php echo e($category->id); ?></div>
                <div class="card-body">
                    <a href="<?php echo e(url('/category')); ?>" title="Back">
                        <button class="btn btn-warning btn-sm mr-2">
                            <i class="fas fa-undo" aria-hidden="true"></i>
                            Back
                        </button>
                    </a>
                    <a href="<?php echo e(url('/category/' . $category->id . '/edit')); ?>" title="Edit Category">
                        <button class="btn btn-primary btn-sm mr-2">
                            <i class="far fa-edit" aria-hidden="true"></i>
                            Edit
                        </button>
                    </a>

                    <form method="POST" action="<?php echo e(url('category' . '/' . $category->id)); ?>" accept-charset="UTF-8"
                        style="display:inline">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-danger btn-sm" title="Delete Category"
                            onclick="return confirm(&quot;Confirm delete?&quot;)">
                            <i class="far fa-trash-alt" aria-hidden="true"></i>
                            Delete
                        </button>
                    </form>
                    <br>
                    <br>

                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tbody>
                                <tr>
                                    <th>รหัส</th>
                                    <td><?php echo e($category->id); ?></td>
                                </tr>
                                <tr>
                                    <th> ประเภทหลัก </th>
                                    <td> <?php echo e($category->name); ?> </td>
                                </tr>
                                <tr>
                                    <th> ประเภทย่อย </th>
                                    <td> <?php echo e($category->sub_name); ?> </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/category/show.blade.php ENDPATH**/ ?>