<?php $__env->startSection('title','KhaoPan Shop | Product'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .created_at span {
        font-size: 12px;
    }

    .mycheckout span,
    a {
        font-size: 14px;
    }

    .mycheckout p {
        font-size: 16px;
    }

    .mycheckout table th,
    td {
        font-size: 14px;
    }
    .checkout{
        font-size: 16px;
    }
</style>
<!-- product category -->
<section id="aa-product-category">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-9 col-sm-8 col-md-push-3">
                <div class="aa-product-catg-content">
                    <?php if($order->count()): ?>
                    <div class="aa-product-inner">
                        <!-- start prduct navigation -->
                        <ul class="nav nav-tabs aa-products-tab">
                            <li class="active"><a href="#all" data-toggle="tab">ทั้งหมด</a></li>
                            <li><a href="#paid" data-toggle="tab">รอตรวจสอบ</a></li>
                            <li><a href="#checking" data-toggle="tab">รอจัดส่ง</a></li>
                            <li><a href="#sent" data-toggle="tab">จัดส่งแล้ว</a></li>
                            <li><a href="#completed" data-toggle="tab">ได้รับสินค้าแล้ว</a></li>
                            <li><a href="#cancelled" data-toggle="tab">ยกเลิก</a></li>
                        </ul>
                        <br>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane fade in active" id="all">
                                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-6 created_at">
                                        <a class="checkout"><?php echo e('หมายเลยคำสั่งซื้อ # ' . $item_po->id); ?><a><br>
                                                <span><?php echo e('สั่งเมื่อวันที่ ' . $item_po->created_at); ?></span>
                                    </div>
                                    <div class="col-md-6 mycheckout text-right">
                                        <a href="<?php echo e(url('mycheckout-detail/'.$item_po->id)); ?>" type="button" class="btn btn-danger" target="_blank">ดูรายการ</a>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item_po->id == $item->po_id): ?>
                                <div class="row">
                                    <div class="col-md-2">
                                        <a href="<?php echo e(url('product-detail?search='.$item->prod_id)); ?>">
                                            <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->product->photo1); ?>"
                                                class="img-rounded center-block" alt="img" width="80px" height="80px">
                                        </a>
                                    </div>
                                    <div class="col-md-4 mycheckout">
                                        <a class="aa-cart-title" href="javascript:void(0)">
                                            <?php echo e($item->product->name); ?>

                                        </a>
                                    </div>
                                    <div class="col-md-2 mycheckout">
                                        <span><?php echo e('฿ '. number_format($item->product->price,2)); ?></span>
                                    </div>
                                    <div class="col-md-2 mycheckout">
                                        <span> <?php echo e('Qty : ' .$item->qty); ?></span>
                                    </div>
                                    <div class="col-md-2 mycheckout">
                                        <span><?php echo e($item_po->status); ?></span>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="tab-pane fade in" id="paid">
                                <?php if($paid->count()): ?>
                                    <?php $__currentLoopData = $paid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-6 created_at">
                                            <a class="checkout"><?php echo e('หมายเลยคำสั่งซื้อ # ' . $item_po->id); ?><a><br>
                                                    <span><?php echo e('สั่งเมื่อวันที่ ' . $item_po->created_at); ?></span>
                                        </div>
                                        <div class="col-md-6 mycheckout text-right">
                                            <a href="<?php echo e(url('mycheckout-detail/'.$item_po->id)); ?>" type="button" class="btn btn-danger" target="_blank">ดูรายการ</a>
                                        </div>
                                    </div>
                                        <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item_po->id == $item->po_id): ?>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <a href="<?php echo e(url('product-detail?search='.$item->prod_id)); ?>">
                                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->product->photo1); ?>"
                                                            class="img-rounded center-block" alt="img" width="80px" height="80px">
                                                    </a>
                                                </div>
                                                <div class="col-md-4 mycheckout">
                                                    <a class="aa-cart-title" href="javascript:void(0)">
                                                        <?php echo e($item->product->name); ?>

                                                    </a>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span><?php echo e('฿ '. number_format($item->product->price,2)); ?></span>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span> <?php echo e('Qty : ' .$item->qty); ?></span>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span><?php echo e($item_po->status); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <div class="row">
                                    <div class="col-md created_at text-center">
                                        <a class="checkout">ไม่มีรายการรอตรวจสอบคะ<a><br>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>

                            <div class="tab-pane fade in" id="checking">
                                <?php if($checking->count()): ?>
                                    <?php $__currentLoopData = $checking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-6 created_at">
                                            <a class="checkout"><?php echo e('หมายเลยคำสั่งซื้อ # ' . $item_po->id); ?><a><br>
                                                    <span><?php echo e('สั่งเมื่อวันที่ ' . $item_po->created_at); ?></span>
                                        </div>
                                        <div class="col-md-6 mycheckout text-right">
                                            <a href="<?php echo e(url('mycheckout-detail/'.$item_po->id)); ?>" type="button" class="btn btn-danger" target="_blank">ดูรายการ</a>
                                        </div>
                                    </div>
                                        <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item_po->id == $item->po_id): ?>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <a href="<?php echo e(url('product-detail?search='.$item->prod_id)); ?>">
                                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->product->photo1); ?>"
                                                            class="img-rounded center-block" alt="img" width="80px" height="80px">
                                                    </a>
                                                </div>
                                                <div class="col-md-4 mycheckout">
                                                    <a class="aa-cart-title" href="javascript:void(0)">
                                                        <?php echo e($item->product->name); ?>

                                                    </a>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span><?php echo e('฿ '. number_format($item->product->price,2)); ?></span>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span> <?php echo e('Qty : ' .$item->qty); ?></span>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span><?php echo e($item_po->status); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <div class="row">
                                    <div class="col-md created_at text-center">
                                        <a class="checkout">ไม่มีรายการรอจัดส่งคะ<a><br>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>

                            <div class="tab-pane fade in" id="sent">
                                <?php if($sent->count()): ?>
                                    <?php $__currentLoopData = $sent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-6 created_at">
                                            <a class="checkout"><?php echo e('หมายเลยคำสั่งซื้อ # ' . $item_po->id); ?><a><br>
                                                    <span><?php echo e('สั่งเมื่อวันที่ ' . $item_po->created_at); ?></span>
                                        </div>
                                        <div class="col-md-6 mycheckout text-right">
                                            <a href="<?php echo e(url('mycheckout-detail/'.$item_po->id)); ?>" type="button" class="btn btn-danger" target="_blank">ดูรายการ</a>
                                        </div>
                                    </div>
                                        <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item_po->id == $item->po_id): ?>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <a href="<?php echo e(url('product-detail?search='.$item->prod_id)); ?>">
                                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->product->photo1); ?>"
                                                            class="img-rounded center-block" alt="img" width="80px" height="80px">
                                                    </a>
                                                </div>
                                                <div class="col-md-4 mycheckout">
                                                    <a class="aa-cart-title" href="javascript:void(0)">
                                                        <?php echo e($item->product->name); ?>

                                                    </a>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span><?php echo e('฿ '. number_format($item->product->price,2)); ?></span>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span> <?php echo e('Qty : ' .$item->qty); ?></span>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span><?php echo e($item_po->status); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <div class="row">
                                    <div class="col-md created_at text-center">
                                        <a class="checkout">ไม่มีรายการจัดส่งแล้วคะ<a><br>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>

                            <div class="tab-pane fade in" id="completed">
                                <?php if($completed->count()): ?>
                                    <?php $__currentLoopData = $completed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-6 created_at">
                                            <a class="checkout"><?php echo e('หมายเลยคำสั่งซื้อ # ' . $item_po->id); ?><a><br>
                                                    <span><?php echo e('สั่งเมื่อวันที่ ' . $item_po->created_at); ?></span>
                                        </div>
                                        <div class="col-md-6 mycheckout text-right">
                                            <a href="<?php echo e(url('mycheckout-detail/'.$item_po->id)); ?>" type="button" class="btn btn-danger" target="_blank">ดูรายการ</a>
                                        </div>
                                    </div>
                                        <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item_po->id == $item->po_id): ?>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <a href="<?php echo e(url('product-detail?search='.$item->prod_id)); ?>">
                                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->product->photo1); ?>"
                                                            class="img-rounded center-block" alt="img" width="80px" height="80px">
                                                    </a>
                                                </div>
                                                <div class="col-md-4 mycheckout">
                                                    <a class="aa-cart-title" href="javascript:void(0)">
                                                        <?php echo e($item->product->name); ?>

                                                    </a>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span><?php echo e('฿ '. number_format($item->product->price,2)); ?></span>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span> <?php echo e('Qty : ' .$item->qty); ?></span>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span><?php echo e($item_po->status); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <div class="row">
                                    <div class="col-md created_at text-center">
                                        <a class="checkout">ไม่มีรายการได้รับสินค้าแล้วคะ<a><br>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>

                            <div class="tab-pane fade in" id="cancelled">
                                <?php if($cancelled->count()): ?>
                                    <?php $__currentLoopData = $cancelled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-6 created_at">
                                            <a class="checkout"><?php echo e('หมายเลยคำสั่งซื้อ # ' . $item_po->id); ?><a><br>
                                                    <span><?php echo e('สั่งเมื่อวันที่ ' . $item_po->created_at); ?></span>
                                        </div>
                                        <div class="col-md-6 mycheckout text-right">
                                            <a href="<?php echo e(url('mycheckout-detail/'.$item_po->id)); ?>" type="button" class="btn btn-danger" target="_blank">ดูรายการ</a>
                                        </div>
                                    </div>
                                        <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item_po->id == $item->po_id): ?>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <a href="<?php echo e(url('product-detail?search='.$item->prod_id)); ?>">
                                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->product->photo1); ?>"
                                                            class="img-rounded center-block" alt="img" width="80px" height="80px">
                                                    </a>
                                                </div>
                                                <div class="col-md-4 mycheckout">
                                                    <a class="aa-cart-title" href="javascript:void(0)">
                                                        <?php echo e($item->product->name); ?>

                                                    </a>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span><?php echo e('฿ '. number_format($item->product->price,2)); ?></span>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span> <?php echo e('Qty : ' .$item->qty); ?></span>
                                                </div>
                                                <div class="col-md-2 mycheckout">
                                                    <span><?php echo e($item_po->status); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <div class="row">
                                    <div class="col-md created_at text-center">
                                        <a class="checkout">ไม่มีรายการที่ยกเลิกคะ<a><br>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                    <?php else: ?>
                    <div class="col-md text-center" style="margin-top: 50px;">
                        <a href="<?php echo e(url('home')); ?>" class="aa-browse-btn">เลือกชื้อสินค้า</a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-4 col-md-pull-9">
                <aside class="aa-sidebar">
                    <!-- single sidebar -->
                    <div class="aa-sidebar-widget">
                        <h3>รายการสินค้า</h3>
                        <ul class="aa-catg-nav">
                            <?php $__currentLoopData = App\Category::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url('products?category='.$cat->id)); ?>"><?php echo e($cat->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="aa-sidebar-widget">
                        <h3></h3>
                        <ul class="aa-catg-nav">
                            <li><a href="<?php echo e(url('myaccount')); ?>"><i class="far fa-user-circle"></i> บัญชีของฉัน</a></li>
                            <li><a href="<?php echo e(url('mywishlist')); ?>"><i class="far fa-heart"></i></i> สิ่งที่ฉันอยากได้</a></li>
                            <li><a href="<?php echo e(url('mycart')); ?>"><i class="fas fa-cart-arrow-down"></i> รถเข็นของฉัน</a></li>
                            <li><a href="<?php echo e(url('mycheckout')); ?>"><i class="far fa-bookmark"></i> คำสั่งชื่อของฉัน</a></li>
                        </ul>
                    </div>

                </aside>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>

</section>
<!-- / product category -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dailyshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\khaopanshop\resources\views/checkout.blade.php ENDPATH**/ ?>