<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    รายการประเภทของสินค้า
                    <?php if(session('alert')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('alert')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(session('alertFail')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('alertFail')); ?>

                    </div>
                    <?php endif; ?>

                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <a href="<?php echo e(url('/category/create?create=category')); ?>" class="btn btn-info mr-2"
                                title="เพิ่มประเภทหลัก">
                                <i class="fa fa-plus" aria-hidden="true"></i>
                                เพิ่มประเภทหลัก
                            </a>
                            <a href="<?php echo e(url('/category/create?create=category_sub')); ?>" class="btn btn-primary"
                                title="เพิ่มประเภทย่อย">
                                <i class="fa fa-plus" aria-hidden="true"></i>
                                เพิ่มประเภทย่อย
                            </a>
                        </div>
                        <div class="col-md-4 text-right">
                            <form method="GET" action="<?php echo e(url('/category')); ?>" accept-charset="UTF-8"
                                class="form-inline my-2 my-lg-0 float-right" role="search">
                                <div class="form-group">
                                    <select class="custom-select" id="cat_id" name="cat_id" required>
                                        <option value="">เลือกประเภท...</option>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="input-group-append">
                                        <button class="btn btn-secondary" type="submit">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </span>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-2 text-right">
                            <a href="<?php echo e(url('/category')); ?>" class="btn btn-success float-right" title="ทั้งหมด">
                                ทั้งหมด
                            </a>
                        </div>
                    </div>

                    <br />
                    <div class="table-responsive">
                        <table class="table table-striped table-sm">
                            <thead>
                                <tr>
                                    <th class="text-center">ลำดับ</th>
                                    <th>ประเภท</th>
                                    <th>ประเภทย่อย</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $category_sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center">
                                        <?php echo e(($category_sub ->currentpage()-1) * $category_sub ->perpage() + $loop->index + 1); ?>

                                    </td>
                                    <td><?php echo e($item->category->name); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(url('/category/' . $item->id . '/edit')); ?>" title="Edit Category">
                                            <button class="btn btn-primary btn-sm mr-2">
                                                แก้ไข
                                            </button>
                                        </a>
                                        <form method="POST" action="<?php echo e(url('/category' . '/' . $item->id)); ?>"
                                            accept-charset="UTF-8" style="display:inline">
                                            <?php echo e(method_field('DELETE')); ?>

                                            <?php echo e(csrf_field()); ?>

                                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Category"
                                                onclick="return confirm(&quot;คุณแน่ใจใช่หรือไม่ที่จะลบรายการนี้ ?&quot;)">
                                                ลบ
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="pagination-wrapper float-right">
                            <?php echo $category_sub->appends(['search' => Request::get('search')])->render(); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/category/index.blade.php ENDPATH**/ ?>