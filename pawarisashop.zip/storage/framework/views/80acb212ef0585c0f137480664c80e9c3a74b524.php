<?php $__env->startSection('title','KhaoPan Shop | My Cart'); ?>

<?php $__env->startSection('content'); ?>

<!-- Cart view section -->
<section id="cart-view">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="cart-view-area">
                    <div class="cart-view-table">
                        <?php if($orderproduct->count()): ?>
                        <form method="POST" action="<?php echo e(url('order-product-mycart-update')); ?>" accept-charset="UTF-8"
                            class="form-horizontal" enctype="multipart/form-data">
                            <?php echo e(method_field('PATCH')); ?>

                            <?php echo e(csrf_field()); ?>

                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>ลำดับ</th>
                                            <th>รูปสินค้า</th>
                                            <th>สินค้า</th>
                                            <th>ขนาด</th>
                                            <th>ราคา/ชิ้น</th>
                                            <th>เหลืออยู่</th>
                                            <th>ส่วนลด/ชิ้น</th>
                                            <th>จำนวน</th>
                                            <th>ราคารวม</th>
                                            <th>ยกเลิก</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $orderproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td>
                                                <a href="javascript:void(0)">
                                                    <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($item->product->photo1); ?>"
                                                        alt="img">
                                                </a>
                                            </td>
                                            <td>
                                                <a class="aa-cart-title" href="javascript:void(0)">
                                                    <?php echo e($item->product->name); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e($item->product->size); ?></td>
                                            <td><?php echo e(number_format($item->product->price,2)); ?></td>
                                            <td><?php echo e($item->product->qty); ?></td>
                                            <td><?php echo e(number_format($item->product->disc,2)); ?></td>
                                            <td>
                                                <input type="hidden" name="id<?php echo e($item->id); ?>" id="id<?php echo e($item->id); ?>"
                                                    value="<?php echo e($item->id); ?>">

                                                <input type="hidden" name="qty_old<?php echo e($item->id); ?>" id="qty_old<?php echo e($item->id); ?>"
                                                    value="<?php echo e($item->qty); ?>">

                                                <input class="aa-cart-quantity" type="number" name="qty<?php echo e($item->id); ?>"
                                                    id="qty<?php echo e($item->id); ?>" value="<?php echo e($item->qty); ?>" min="1">
                                            </td>
                                            <td><?php echo e(number_format($item->net,2)); ?></td>
                                            <td>
                                                <a class="remove" href="<?php echo e(url('mycart-delete/'. $item->id)); ?>">
                                                    <i class="far fa-times-circle" style="font-size: 24px;"></i>
                                                </a>
                                                <input type="hidden" name="prod_id" id="prod_id" value="<?php echo e($item->prod_id); ?>">
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="10" class="aa-cart-view-bottom">
                                                <div class="row">
                                                    <div class="col-md-10 text-left float-felt">
                                                        <div class="checkout-right">
                                                            <label>ที่อยู่ในการจัดส่งสินค้า : </label>
                                                            <div class="">
                                                                <label>ชื่อ : <?php echo e($profile->name); ?></label>
                                                                <label>ที่อยู่ : <?php echo e($profile->address); ?></label>
                                                                <label>โทร : <?php echo e($profile->phone); ?></label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <input class="aa-cart-view-btn" type="submit"
                                                            value="แก้ไขรถเข็นของฉัน">
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                        <?php else: ?>
                        <div class="col-md text-center" style="margin-top: 50px;">
                            <a href="<?php echo e(url('home')); ?>" class="aa-browse-btn">เลือกชื้อสินค้า</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- / Cart view section -->
<!-- Cart view section -->
<?php if($orderproduct->count()): ?>
<section id="checkout">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form method="POST" action="<?php echo e(url('order-product-mycheckout')); ?>" accept-charset="UTF-8"
                    class="form-horizontal" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="checkout-area">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="checkout-left">
                                    <div class="checkout-right">
                                        <h4>สรุปยอดสั่งสินค้า : ซื้อสินค้าครบ 300 บาทบริการจัดส่งฟรี</h4>
                                        <div class="aa-order-summary-area">
                                            <table class="table table-responsive">
                                                <thead>
                                                    <tr>
                                                        <th>สินค้า</th>
                                                        <th>จำนวน</th>
                                                        <th>ราคา</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $orderproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($item->product->name); ?></td>
                                                        <td><?php echo e($item->qty); ?></td>
                                                        <td><?php echo e(number_format($item->price * $item->qty,2)); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                                <?php
                                                if ($sumNet >= 300) {
                                                    $shipping = 0;
                                                    $sumNet = $sumNet + $shipping;
                                                }else{
                                                    $shipping = 50;
                                                    $sumNet = $sumNet + $shipping;
                                                }
                                                ?>
                                                <tfoot>
                                                    <tr>
                                                        <th colspan="2">ส่วนลด</th>
                                                        <td>
                                                            <?php if($sumDisc > 0): ?>
                                                            <?php echo e(number_format($sumDisc,2) . ' บาท'); ?>

                                                            <?php else: ?>
                                                            <?php echo e('รายการสินค้าไม่มีส่วนลดคะ'); ?>

                                                            <?php endif; ?>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="2">ค่าจัดส่ง</th>
                                                        <td>
                                                            <?php if($shipping > 0 ): ?>
                                                            <?php echo e(number_format($shipping,2) . ' บาท'); ?>

                                                            <?php else: ?>
                                                            <?php echo e('จัดส่งฟรี'); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="2">ร่วมจ่ายสุทธิ</th>
                                                        <td><?php echo e(number_format($sumNet,2) . ' บาท'); ?></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div class="checkout-right">
                                    <h4>วิธีชำระเงิน</h4>
                                    <div class="aa-payment-method">
                                        <table class="table table-borderless">
                                            <tbody>
                                                <tr>
                                                    <td scope="row">
                                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->bbl_logo); ?>">
                                                    </td>
                                                    <td>
                                                        <?php echo e($config->scb); ?>

                                                        <a href="http://" target="_blank" rel="">
                                                            <img src="<?php echo e(url('/')); ?>/storage/config/QR.jpg">
                                                        </a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row">
                                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->kbsnk_logo); ?>">
                                                    </td>
                                                    <td>
                                                        <?php echo e($config->kbsnk); ?>

                                                        <a href="http://" target="_blank" rel="">
                                                            <img src="<?php echo e(url('/')); ?>/storage/config/QR.jpg">
                                                        </a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row">
                                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->scb_logo); ?>">
                                                    </td>
                                                    <td>
                                                        <?php echo e($config->scb); ?>

                                                        <a href="http://" target="_blank" rel="">
                                                        <img src="<?php echo e(url('/')); ?>/storage/config/QR.jpg">
                                                        </a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row">
                                                        <img src="<?php echo e(url('/')); ?>/storage/<?php echo e($config->bay_logo); ?>">
                                                    </td>
                                                    <td>
                                                        <?php echo e($config->bay); ?>

                                                        <a href="http://" target="_blank" rel="">
                                                            <img src="<?php echo e(url('/')); ?>/storage/config/QR.jpg">
                                                        </a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--
                                            <label for="cashdelivery"><input type="radio" id="cashdelivery"
                                                    name="optionsRadios"> Cash on Delivery </label>
                                            <label for="paypal"><input type="radio" id="paypal" name="optionsRadios"
                                                    checked> Via Paypal </label>
                                            -->
                                        <div class="col-md">
                                            <div name="receipt" id="receipt" class="text-center receipt">
                                            </div>
                                        </div>
                                        <input type="file" id="slip" name="slip" class="aa-browse-btn form-control"
                                            required>
                                        <input type="hidden" id="shipping" name="shipping" value="<?php echo e($shipping); ?>">
                                        <input type="submit" value="สังชื้อสินค้า" class="aa-browse-btn">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<!-- / Cart view section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dailyshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ProjectsLaravel\KhaoPan-Shop\resources\views/cart.blade.php ENDPATH**/ ?>